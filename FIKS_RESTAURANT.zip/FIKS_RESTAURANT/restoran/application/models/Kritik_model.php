<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Kritik_model extends CI_Model
{
    public function insert_kritik($data)
    {
        $this->db->insert('kritik_saran', $data);
    }
}
