<?php
defined('BASEPATH') or exit('No direct script access allowed');

class KritikSaranModel extends CI_Model
{
    public function getAllKritikSaran($search = null)
    {
        if ($search) {
            $this->db->like('nama_pelanggan', $search);
            $this->db->or_like('email', $search);
            $this->db->or_like('kritik_saran', $search);
        }
        return $this->db->get('kritik_saran')->result();
    }

    public function insertKritikSaran($data)
    {
        return $this->db->insert('kritik_saran', $data);
    }

    public function getKritikSaranById($id)
    {
        return $this->db->get_where('kritik_saran', array('id' => $id))->row();
    }

    public function updateKritikSaran($id, $data)
    {
        $this->db->where('id', $id);
        return $this->db->update('kritik_saran', $data);
    }

    public function deleteKritikSaran($id)
    {
        $this->db->where('id', $id);
        return $this->db->delete('kritik_saran');
    }
}
