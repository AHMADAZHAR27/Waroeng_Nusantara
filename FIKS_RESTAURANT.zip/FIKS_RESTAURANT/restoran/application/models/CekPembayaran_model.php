<?php
defined('BASEPATH') or exit('No direct script access allowed');

class CekPembayaran_model extends CI_Model
{
    public function getReservasi($search = null)
    {
        if ($search) {
            $this->db->like('kode_pembayaran', $search);
            $this->db->or_like('nama', $search);
        }
        $query = $this->db->get('reservasi');
        return $query->result();
    }
}
