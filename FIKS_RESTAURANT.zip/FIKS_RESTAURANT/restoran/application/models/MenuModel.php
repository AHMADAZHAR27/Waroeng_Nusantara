<?php
defined('BASEPATH') or exit('No direct script access allowed');

class MenuModel extends CI_Model
{
    public function getMenus()
    {
        $query = $this->db->get('menu');
        return $query->result();
    }

    public function insertMenu($data)
    {
        return $this->db->insert('menu', $data);
    }

    public function updateMenu($id, $data)
    {
        $this->db->where('id_menu', $id);
        return $this->db->update('menu', $data);
    }

    public function deleteMenu($id)
    {
        $this->db->where('id_menu', $id);
        return $this->db->delete('menu');
    }

    public function searchMenus($query)
    {
        $this->db->like('nama_menu', $query);
        $this->db->or_like('detail_menu', $query);
        return $this->db->get('menu')->result();
    }
}
