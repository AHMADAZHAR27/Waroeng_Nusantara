<?php
defined('BASEPATH') or exit('No direct script access allowed');

class ReservasiAdmin_model extends CI_Model
{
    public function getAllReservasi($search = null)
    {
        $this->db->select('r.*, m.nomor_meja');
        $this->db->from('reservasi r');
        $this->db->join('meja m', 'r.meja = m.id_meja');
        if ($search) {
            $this->db->like('r.nama', $search);
            $this->db->or_like('r.kode_pembayaran', $search);
            $this->db->or_like('r.no_hp', $search);
            $this->db->or_like('r.meja', $search);
            $this->db->or_like('r.total_pembayaran', $search);
            $this->db->or_like('r.status_pembayaran', $search);
        }
        $query = $this->db->get();
        return $query->result();
    }

    public function getMenuByReservasiId($id_reservasi)
    {
        $this->db->select('rm.*, m.nama_menu, m.harga');
        $this->db->from('reservasi_menu rm');
        $this->db->join('menu m', 'rm.id_menu = m.id_menu');
        $this->db->where('rm.id_reservasi', $id_reservasi);
        $query = $this->db->get();
        return $query->result();
    }

    public function getReservasiById($id_reservasi)
    {
        $this->db->select('r.*, m.nomor_meja');
        $this->db->from('reservasi r');
        $this->db->join('meja m', 'r.meja = m.id_meja');
        $this->db->where('r.id_reservasi', $id_reservasi);
        $query = $this->db->get();
        return $query->row();
    }

    public function updateReservasi($id_reservasi, $data)
    {
        $this->db->where('id_reservasi', $id_reservasi);
        $this->db->update('reservasi', $data);
    }

    public function deleteReservasi($id_reservasi)
    {
        $this->db->where('id_reservasi', $id_reservasi);
        $this->db->delete('reservasi');
    }

    public function deleteMenuByReservasiId($id_reservasi)
    {
        $this->db->where('id_reservasi', $id_reservasi);
        $this->db->delete('reservasi_menu');
    }
}
