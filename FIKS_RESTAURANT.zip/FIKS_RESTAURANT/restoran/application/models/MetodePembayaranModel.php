<?php
defined('BASEPATH') or exit('No direct script access allowed');

class MetodePembayaranModel extends CI_Model
{
    public function getAllMetodePembayaran($search = null)
    {
        if ($search) {
            $this->db->like('bank', $search);
            $this->db->or_like('rekening', $search);
            $this->db->or_like('nama_rekening', $search);
        }
        return $this->db->get('metode_pembayaran')->result();
    }

    public function insertMetodePembayaran($data)
    {
        return $this->db->insert('metode_pembayaran', $data);
    }

    public function getMetodePembayaranById($id)
    {
        return $this->db->get_where('metode_pembayaran', array('id_mp' => $id))->row();
    }

    public function updateMetodePembayaran($id, $data)
    {
        $this->db->where('id_mp', $id);
        return $this->db->update('metode_pembayaran', $data);
    }

    public function deleteMetodePembayaran($id)
    {
        $this->db->where('id_mp', $id);
        return $this->db->delete('metode_pembayaran');
    }
}
