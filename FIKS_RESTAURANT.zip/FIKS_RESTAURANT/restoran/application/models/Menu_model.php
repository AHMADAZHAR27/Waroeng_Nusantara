<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Menu_model extends CI_Model {
    public function __construct() {
        $this->load->database();
    }

    public function get_menu() {
        $query = $this->db->get('menu');
        return $query->result_array();
    }

    public function get_random_menu($limit = 3) {
        $this->db->order_by('id_menu', 'RANDOM');
        $this->db->limit($limit);
        $query = $this->db->get('menu');
        return $query->result_array();
    }
}
?>
