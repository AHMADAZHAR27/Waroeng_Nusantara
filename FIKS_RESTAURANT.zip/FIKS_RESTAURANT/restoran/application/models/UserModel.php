<?php
defined('BASEPATH') or exit('No direct script access allowed');

class UserModel extends CI_Model
{

    public function __construct()
    {
        parent::__construct();
        $this->load->database();
    }


    public function login_user($username, $password)
    {
        $this->db->where('username', $username);
        $query = $this->db->get('user');

        if ($query->num_rows() == 1) {
            $user = $query->row();
            if ($password == $user->password) {
                return $user;
            } else {
                return false;
            }
        } else {
            return false;
        }
    }

    public function get_user_by_id($id)
    {
        $this->db->where('iduser', $id);
        $query = $this->db->get('user');
        return $query->row();
    }
}
