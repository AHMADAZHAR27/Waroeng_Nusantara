<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Reservasi_model extends CI_Model
{
    public function getReservasiByKode($kode_pembayaran)
    {
        return $this->db->get_where('reservasi', ['kode_pembayaran' => $kode_pembayaran])->row();
    }

    public function insert_reservasi($data)
    {
        $this->db->insert('reservasi', $data);
        return $this->db->insert_id();
    }

    public function insert_reservasi_menu($data)
    {
        $this->db->insert('reservasi_menu', $data);
    }

    public function update_reservasi($kode_pembayaran, $data)
    {
        $this->db->where('kode_pembayaran', $kode_pembayaran);
        return $this->db->update('reservasi', $data);
    }


    public function getAllReservasi($search = null)
    {
        $this->db->select('*');
        $this->db->from('reservasi');
        $query = $this->db->get();

        if ($search) {
            $this->db->like('kode_pembayaran', $search);
            $this->db->or_like('nama', $search);
        }
        return $this->db->get('reservasi')->result();
    }

    public function getMenuByKodePembayaran($kode_pembayaran)
    {
        $this->db->select('m.nama_menu, rm.jumlah, m.harga');
        $this->db->from('reservasi_menu rm');
        $this->db->join('menu m', 'rm.id_menu = m.id_menu');
        $this->db->join('reservasi r', 'rm.id_reservasi = r.id_reservasi');
        $this->db->where('r.kode_pembayaran', $kode_pembayaran);
        $query = $this->db->get();
        return $query->result();
    }

    public function getMejaByKodePembayaran($kode_pembayaran)
    {
        $this->db->select('meja.nomor_meja');
        $this->db->from('reservasi');
        $this->db->join('meja', 'reservasi.meja = meja.id_meja');
        $this->db->where('reservasi.kode_pembayaran', $kode_pembayaran);
        $query = $this->db->get();
        return $query->row();
    }

    

}
