<?php
defined('BASEPATH') or exit('No direct script access allowed');

class MejaModel extends CI_Model
{
    public function getAllMeja($search = null)
    {
        if ($search) {
            $this->db->like('nomor_meja', $search);
            $this->db->or_like('kapasitas', $search);
        }
        return $this->db->get('meja')->result();
    }

    public function insertMeja($data)
    {
        return $this->db->insert('meja', $data);
    }

    public function getMejaById($id)
    {
        return $this->db->get_where('meja', array('id_meja' => $id))->row();
    }

    public function updateMeja($id, $data)
    {
        $this->db->where('id_meja', $id);
        return $this->db->update('meja', $data);
    }

    public function deleteMeja($id)
    {
        $this->db->where('id_meja', $id);
        return $this->db->delete('meja');
    }
}
