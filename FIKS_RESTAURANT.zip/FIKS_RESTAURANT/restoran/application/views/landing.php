<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8" />
  <meta http-equiv="X-UA-Compatible" content="IE=edge" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Restuarant Website</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
  <!-- remix icon cdn -->
  <link href="https://cdn.jsdelivr.net/npm/remixicon@2.5.0/fonts/remixicon.css" rel="stylesheet" />

  <!-- custom css file  -->
  <link rel="stylesheet" href="<?php echo base_url('asset/style.css'); ?>" />

  <style>
        .dishes__wrapper {
            display: flex;
            flex-wrap: wrap;
            gap: 20px;
            justify-content: center;
        }

        .dish__item {
            flex: 1 1 calc(33.333% - 20px);
            /* Batasi tiga item per baris */
            max-width: calc(33.333% - 20px);
            box-sizing: border-box;
            text-align: left;
            background: #4b3621;
            border-radius: 10px;
            padding: 10px;
            gap: 20px;
            align-items: center;
            /* Atur agar item di tengah secara vertikal */
            display: flex;
            flex-direction: row;
            /* Atur arah tata letak menjadi horizontal */
        }

        .dish__img {
            width: 100px;
            /* Atur lebar gambar */
            height: 100px;
            /* Atur tinggi gambar untuk proporsi 1:1 */
            overflow: hidden;
            border-radius: 10px;
            display: flex;
            justify-content: center;
            align-items: center;
            flex-shrink: 0;
        }

        .dish__img img {
            width: 100%;
            height: 100%;
            object-fit: cover;
            /* Menjaga proporsi gambar */
            border-radius: 10px;
        }

        .dish__content {
            flex: 1;
            text-align: left;
        }

        .dish__content h3 {
            text-align: left;
            margin: 0;
        }

        .dish__content-bottom {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-top: 10px;
        }

        .dish__price {
            font-weight: bold;
        }

        .dish__stock {
            color: green;
        }

        .dish__stock.habis {
            color: red;
        }

        .add__to-cart i {
            color: yellow;
        }
    </style>
</head>

<body>
  <!-- =========== header start ============ -->
  <header class="header">
    <nav class="nav">
      <div class="container">
        <div class="nav__wrapper">
          <div class="logo">
            <h1>RESER<span class="highlight">VASI</span></h1>
          </div>

          <div class="navigation">
            <ul class="nav__menu">
              <li class="nav__item">
                <a onclick="window.location.href='<?php echo site_url('Landing'); ?>'" class="nav__link">Home</a>
              </li>
              <li class="nav__item">
                <a onclick="window.location.href='<?php echo site_url('Katalog'); ?>'" class="nav__link">Katalog Menu</a>
              </li>
              <li class="nav__item">
                <a onclick="window.location.href='<?php echo site_url('Reservasi'); ?>'" class="nav__link">Reservasi</a>
              </li>
              <li class="nav__item">
                <a onclick="window.location.href='<?php echo site_url('CekPembayaran'); ?>'" class="nav__link">Cek Pembayaran</a>
              </li>
              <li class="nav__item">
                <a onclick="window.location.href='<?php echo site_url('Kritik'); ?>'" class="nav__link">Kritik & Saran</a>
              </li>
            </ul>
          </div>

          <span class="mobile__menu"><i class="ri-menu-line"></i></span>
        </div>
      </div>
    </nav>
  </header>

  <!-- =========== header end ============ -->

  <!-- =========== main start ============ -->
  <main>
    <!-- hero section start -->
    <section id="home" class="section">
      <div class="container">
        <div class="hero__wrapper">
          <div class="hero__content">
            <h2 class="hero__title">Reservasi</h2>
            <h2 class="highlight">Waroeng Nusantara</h2>
            <p>
              Waroeng Nusantara menyediakan layanan reservasi untuk kalian yang ingin menikmati makanan khas
              nusantara kami tanpa harus takut tidak kebagian tempat dan kehabisan makanan,
              Kalian bisa memesan dari jauh-jauh hari jadi jangan khawatir. segera reservasi sekarang juga!!!!
            </p>
          </div>

          <div class="hero__img">
            <img src="<?php echo base_url('asset/gambar/hero.jpg'); ?>" alt="hero-img" />
          </div>
        </div>
      </div>
    </section>

    <!-- hero section start -->

    <!-- popular dishes section start -->
    <section class="section">
      <div class="container">
        <div class="dishes__section-top mt-5">
          <h2>Menu Rekomendasi Hari ini</h2>
        </div>
        <div class="dishes__wrapper">
          <?php foreach ($menu as $item) : ?>
            <div class="dish__item">
              <div class="dish__img">
                <img src="<?php echo base_url($item['gambar_menu']); ?>" alt="" />
              </div>
              <div class="dish__content">
                <h3><?php echo $item['nama_menu']; ?></h3>
                <div class="dish__content-bottom">
                  <span class="dish__price">Rp.<?php echo number_format($item['harga'], 0, ',', '.'); ?></span>
                  <span class="dish__stock <?php echo $item['stok'] == 'Habis' ? 'habis' : ''; ?>">
                    <?php echo $item['stok']; ?>
                  </span>
                </div>
              </div>
            </div>
          <?php endforeach; ?>
        </div>
      </div>
    </section>
    <!-- popular dishes section end -->

  </main>
  <!-- =========== main end ============ -->

  <!-- =========== footer start ============ -->
  <footer class="section footer">
    <div class="container">
      <div class="footer__wrapper">
        <div class="footer__logo">
          <div class="logo">
            <h1>Waroeng<span class="highlight">Nusantara</span></h1>
          </div>
          <button class="btn btn-secondary" onclick="window.location.href='<?php echo site_url('Login'); ?>'">Admin</button>

        </div>

        <div class="footer__box">
          <h3 class="footer__link-title">Location</h3>
          <ul class="footer__menu">
            <li class="footer__menu-item">
              <a href="#about" class="footer__link">Yogyakarta</a>
            </li>
          </ul>
        </div>

        <div class="footer__box">
          <h3 class="footer__link-title">Services</h3>
          <ul class="footer__menu">
            <li class="footer__menu-item">
              <a href="#about" class="footer__link">Online reservasi</a>
            </li>
            <li class="footer__menu-item">
              <a href="#" class="footer__link">Fast Respon</a>
            </li>
            <li class="footer__menu-item">
              <a href="#" class="footer__link">Pre-Reservation</a>
            </li>
            <li class="footer__menu-item">
              <a href="#" class="footer__link">Halal</a>
            </li>
          </ul>
        </div>

        <div class="footer__box">
          <h3 class="footer__link-title">Jam Oprasional</h3>
          <ul class="footer__menu">
            <li class="footer__menu-item">
              <a href="#menu" class="footer__link">Senin-Jum'at: 08:00-22:00</a>
            </li>
            <li class="footer__menu-item">
              <a href="#blog" class="footer__link">Sabtu: 10:00-00:00</a>
            </li>
            <li class="footer__menu-item">
              <a href="#about" class="footer__link">Minggu: 10:00-20:00</a>
            </li>
          </ul>
        </div>

        <div class="footer__box">
          <h3 class="footer__link-title">Social</h3>
          <ul class="footer__menu">
            <li class="footer__menu-item">
              <a href="#" class="footer__link">Facebook</a>
            </li>
            <li class="footer__menu-item">
              <a href="#" class="footer__link">Instagram</a>
            </li>
            <li class="footer__menu-item">
              <a href="#" class="footer__link">Linkedin</a>
            </li>
            <li class="footer__menu-item">
              <a href="#" class="footer__link">Twitter</a>
            </li>
          </ul>
        </div>
      </div>

      <p class="footer__copyright">
        © 2024 Kelompok_3 All Rights Reserved.
      </p>
    </div>
  </footer>
  <!-- =========== footer end ============ -->

  <!-- main js file -->
  <script src="<?php echo base_url('asset/app.js'); ?>"></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
</body>

</html>