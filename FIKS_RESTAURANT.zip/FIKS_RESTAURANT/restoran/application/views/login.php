<!DOCTYPE html>
<html lang="en">

<head>
    <link rel="icon" href="<?php echo base_url('asset/gambar/logo.png'); ?>" type="image/png">
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>Login</title>

    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">

    <style>
        html,
        body {
            height: 100%;
            margin: 0;
            display: flex;
            flex-direction: column;
        }

        .container {
            flex: 1;
            padding: 20px;
        }

        .header,
        .footer {
            background-color: blue;
            color: white;
            padding: 10px 0;
            text-align: center;
            width: 100%;
        }

        .card-container {
            width: auto;
            /* Adjust width */
            margin-top: 2rem;
            /* Spacing between cards */
        }

        .card-body {
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .card-body .card-title {
            margin-bottom: 0;
            /* Removes margin from the card title */
        }

        .login-container {
            max-width: 500px;
            margin: auto;
            padding: 20px;
            box-shadow: 0px 0px 10px 0px rgba(0, 0, 0, 0.1);
            border-radius: 10px;
        }

        .login-container input[type="text"],
        .login-container input[type="password"] {
            width: 100%;
            padding: 10px;
            margin-bottom: 10px;
            border: 1px solid #ccc;
            border-radius: 5px;
        }

        .logo {
            display: block;
            margin: 0 auto 20px;
            width: 100px;
            height: auto;
            margin-right: 70px;
        }

        @media (max-width: 768px) {

            .header,
            .footer {
                padding: 5px 0;
            }

            .search-form form {
                display: block;
            }

            .search-form input[type="text"] {
                width: 100%;
                margin-bottom: 10px;
            }

            .search-form button {
                width: 100%;
            }
        }
    </style>
</head>

<body>
    <div class="header bg-secondary text-center">
        <h1>Waroeng Nusantara</h1>
    </div>
    <h2 class="text-center mt-5">Login</h2>
    <div class="container">
        <div class="login-container card">
            <div class="card-body text-center">
                <img src="<?php echo base_url('asset/gambar/logo.png'); ?>" alt="logo" class="logo">

                <form action="<?php echo site_url('Login/login_process'); ?>" method="post">
                    <div class="form-group">
                        <label for="username">Username</label>
                        <input type="text" name="username" id="username" class="form-control" required>
                    </div>
                    <div class="form-group">
                        <label for="password">Password</label>
                        <input type="password" name="password" id="password" class="form-control" required>
                    </div>
                    <div class="form-group text-center">
                        <button type="submit" class="btn btn-secondary">Login</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    <div class="footer text-center bg-secondary text-white py-3">
        <p>&copy; 2024 Kelompok_3 All rights reserved.</p>
    </div>

</body>

</html>