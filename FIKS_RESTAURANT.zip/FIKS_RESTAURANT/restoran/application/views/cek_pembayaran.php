<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Restuarant Website</title>
    <link rel="icon" href="<?php echo base_url('asset/gambar/logo.png'); ?>" type="image/png">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <!-- remix icon cdn -->
    <link href="https://cdn.jsdelivr.net/npm/remixicon@2.5.0/fonts/remixicon.css" rel="stylesheet" />

    <!-- custom css file  -->
    <link rel="stylesheet" href="<?php echo base_url('asset/style.css'); ?>" />
    <style>
        body {
            color: #fff;
        }

        .table {
            color: #fff;
        }

        .table thead th {
            background-color: #6c757d;
            color: #fff;
        }
    </style>
</head>

<body>
    <!-- =========== header start ============ -->
    <header class="header">
        <nav class="nav">
            <div class="container">
                <div class="nav__wrapper">
                    <div class="logo">
                        <h1>RESER<span class="highlight">VASI</span></h1>
                    </div>

                    <div class="navigation">
                        <ul class="nav__menu">
                            <li class="nav__item">
                                <a onclick="window.location.href='<?php echo site_url('Landing'); ?>'" class="nav__link">Home</a>
                            </li>
                            <li class="nav__item">
                                <a onclick="window.location.href='<?php echo site_url('Katalog'); ?>'" class="nav__link">Katalog Menu</a>
                            </li>
                            <li class="nav__item">
                                <a onclick="window.location.href='<?php echo site_url('Reservasi'); ?>'" class="nav__link">Reservasi</a>
                            </li>
                            <li class="nav__item">
                                <a onclick="window.location.href='<?php echo site_url('CekPembayaran'); ?>'" class="nav__link">Cek Pembayaran</a>
                            </li>
                            <li class="nav__item">
                                <a onclick="window.location.href='<?php echo site_url('Kritik'); ?>'" class="nav__link">Kritik & Saran</a>
                            </li>
                        </ul>
                    </div>

                    <span class="mobile__menu"><i class="ri-menu-line"></i></span>
                </div>
            </div>
        </nav>
    </header>

    <!-- =========== header end ============ -->
    <div class="container mt-5 mb-5">
        <h1>Cek Pembayaran</h1>

        <form method="post" action="<?php echo site_url('CekPembayaran'); ?>">
            <div class="input-group mb-3">
                <input type="text" class="form-control" placeholder="Cari berdasarkan kode pembayaran atau nama" name="search" value="<?php echo $search; ?>">
                <button class="btn btn-secondary" type="submit">Cari</button>
            </div>
        </form>

        <?php if (!empty($search)) : ?>
            <table class="table table-bordered">
                <thead class="bg-secondary text-white">
                    <tr>
                        <th>Kode Pembayaran</th>
                        <th>Tanggal Reservasi</th>
                        <th>Status Pembayaran</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (!empty($reservasi)) : ?>
                        <?php foreach ($reservasi as $r) : ?>
                            <tr>
                                <td><?php echo $r->kode_pembayaran; ?></td>
                                <td><?php echo $r->tanggal_reservasi; ?></td>
                                <td><?php echo $r->status_pembayaran; ?></td>
                                <td>
                                    <?php if ($r->status_pembayaran == 'Belum Dibayar' || $r->status_pembayaran == 'DP Dibayar') : ?>
                                        <a href="<?php echo site_url('Pembayaran/index/' . $r->kode_pembayaran); ?>" class="btn btn-primary">Cek</a>
                                    <?php else : ?>
                                        <span class="badge bg-success">Terverifikasi</span>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php else : ?>
                        <tr>
                            <td colspan="4" class="text-center"> Tidak ada data reservasi ditemukan.
                                <a style="color:blue;" href="<?php echo site_url('CekPembayaran'); ?>">Kembali Mencari</a>
                            </td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        <?php endif; ?>
    </div>
    <!-- =========== footer start ============ -->
    <footer class="section footer mt-5">
        <div class="container">
            <div class="footer__wrapper">
                <div class="footer__logo">
                    <div class="logo">
                        <h1>Waroeng<span class="highlight">Nusantara</span></h1>
                    </div>
                    <button class="btn btn-secondary" onclick="window.location.href='<?php echo site_url('Login'); ?>'">Admin</button>
                </div>

                <div class="footer__box">
                    <h3 class="footer__link-title">Location</h3>
                    <ul class="footer__menu">
                        <li class="footer__menu-item">
                            <a href="#about" class="footer__link">Yogyakarta</a>
                        </li>
                    </ul>
                </div>

                <div class="footer__box">
                    <h3 class="footer__link-title">Services</h3>
                    <ul class="footer__menu">
                        <li class="footer__menu-item">
                            <a href="#about" class="footer__link">Online reservasi</a>
                        </li>
                        <li class="footer__menu-item">
                            <a href="#" class="footer__link">Fast Respon</a>
                        </li>
                        <li class="footer__menu-item">
                            <a href="#" class="footer__link">Pre-Reservation</a>
                        </li>
                        <li class="footer__menu-item">
                            <a href="#" class="footer__link">Halal</a>
                        </li>
                    </ul>
                </div>

                <div class="footer__box">
                    <h3 class="footer__link-title">Jam Oprasional</h3>
                    <ul class="footer__menu">
                        <li class="footer__menu-item">
                            <a href="#menu" class="footer__link">Senin-Jum'at: 08:00-22:00</a>
                        </li>
                        <li class="footer__menu-item">
                            <a href="#blog" class="footer__link">Sabtu: 10:00-00:00</a>
                        </li>
                        <li class="footer__menu-item">
                            <a href="#about" class="footer__link">Minggu: 10:00-20:00</a>
                        </li>
                    </ul>
                </div>

                <div class="footer__box">
                    <h3 class="footer__link-title">Social</h3>
                    <ul class="footer__menu">
                        <li class="footer__menu-item">
                            <a href="#" class="footer__link">Facebook</a>
                        </li>
                        <li class="footer__menu-item">
                            <a href="#" class="footer__link">Instagram</a>
                        </li>
                        <li class="footer__menu-item">
                            <a href="#" class="footer__link">Linkedin</a>
                        </li>
                        <li class="footer__menu-item">
                            <a href="#" class="footer__link">Twitter</a>
                        </li>
                    </ul>
                </div>
            </div>

            <p class="footer__copyright">
                © 2024 Kelompok_3 All Rights Reserved.
            </p>
        </div>
    </footer>
    <!-- =========== footer end ============ -->

    <!-- main js file -->
    <script src="<?php echo base_url('asset/app.js'); ?>"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
</body>

</html>
