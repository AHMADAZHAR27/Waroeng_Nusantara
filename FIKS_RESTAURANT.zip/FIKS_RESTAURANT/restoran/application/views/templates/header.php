<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Waroeng Nusantara</title>
    <link rel="icon" href="<?php echo base_url('asset/gambar/logo.png'); ?>" type="image/png">
    <!-- Bootstrap CSS -->
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <style>
        body,
        html {
            height: 100%;
            margin: 0;
            display: flex;
            flex-direction: column;
            font-family: 'Arial', sans-serif;
        }

        .sidebar {
            width: 250px;
            background: linear-gradient(60deg, #343a40, #697A7F);
            color: white;
            height: 100%;
            position: fixed;
            padding-top: 20px;
            transition: width 0.3s, background-color 0.3s;
            box-shadow: 2px 0 5px rgba(0, 0, 0, 0.1);
        }

        .sidebar.closed {
            width: 80px;
        }

        .sidebar h2 {
            text-align: center;
            font-size: 1.5em;
            font-weight: bold;
        }

        .sidebar .logo {
            text-align: center;
            margin-bottom: 20px;
        }

        .sidebar .logo img {
            width: 80%;
            height: auto;
        }

        .sidebar .menu-item {
            width: 100%;
            padding: 10px 20px;
            margin-top: 10px;
            display: flex;
            align-items: center;
            color: white;
            text-decoration: none;
            transition: background-color 0.3s, padding 0.3s;
            border-bottom: 1px solid rgba(255, 255, 255, 0.2);
        }

        .sidebar .menu-item i {
            margin-right: 15px;
            font-size: 1.2em;
            transition: margin 0.3s;
        }

        .sidebar.closed .menu-item i {
            margin-right: 0;
        }

        .sidebar .menu-item:hover {
            background-color: rgba(0, 0, 0, 0.2);
        }

        .sidebar .menu-item span {
            display: inline-block;
            transition: opacity 0.3s;
            margin-left: 10px;
            font-size: 1em;
        }

        .sidebar.closed .menu-item span {
            opacity: 0;
        }

        .main-content {
            margin-left: 250px;
            display: flex;
            flex-direction: column;
            flex-grow: 1;
            height: 100%;
            transition: margin-left 0.3s;
        }

        .main-content.closed {
            margin-left: 80px;
        }

        .header {
            background: linear-gradient(45deg, #343a40, #697A7F);
            color: white;
            padding: 20px;
            /* Increased padding for larger header */
            flex-shrink: 0;
            display: flex;
            justify-content: space-between;
            align-items: center;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
            margin: 0;
            /* Ensure there's no margin */
        }

        .header h1 {
            margin: 0;
            font-size: 2em;
            /* Increased font size for larger header */
            font-weight: bold;
        }

        .hamburger {
            font-size: 1.5em;
            cursor: pointer;
            transition: transform 0.3s;
        }

        .hamburger:hover {
            transform: scale(1.2);
        }

        .content {
            padding: 20px;
            flex-grow: 1;
            overflow-y: auto;
            background-color: #f8f9fa;
            margin-top: 0;
            /* Remove any top margin */
        }

        .footer {
            background: linear-gradient(45deg, #343a40, #697A7F);
            color: white;
            padding: 10px;
            text-align: center;
            flex-shrink: 0;
            box-shadow: 0 -2px 5px rgba(0, 0, 0, 0.1);
        }

        .container-fluid {
            padding: 0;
        }

        .card {
            margin: 1rem;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            border-radius: 0.5rem;
            overflow: hidden;
        }

        .card-body {
            padding: 1rem;
        }

        .form-inline {
            padding: 1rem 0;
        }

        table {
            width: 100%;
        }

        .d-flex {
            display: flex;
            align-items: center;
        }

        .justify-content-between {
            justify-content: space-between;
        }
    </style>



</head>

<body>
    <div class="sidebar">
        <div class="logo">
            <img src="<?php echo base_url('asset/gambar/logo.png'); ?>" alt="Logo">
        </div>
        <a href="<?php echo site_url('Menu'); ?>" class="menu-item"><i class="fas fa-utensils"></i><span class="menu-text">Menu</span></a>
        <a href="<?php echo site_url('Meja'); ?>" class="menu-item"><i class="fas fa-chair"></i><span class="menu-text">Manajemen Meja</span></a>
        <a href="<?php echo site_url('MetodePembayaran'); ?>" class="menu-item"><i class="fas fa-money-check-alt"></i><span class="menu-text">Kelola Pembayaran</span></a>
        <a href="<?php echo site_url('ReservasiAdmin'); ?>" class="menu-item"><i class="fas fa-history"></i><span>Reservasi</span></a>
        <a href="<?php echo site_url('KritikSaran'); ?>" class="menu-item"><i class="fas fa-comments"></i><span class="menu-text">Kritik & Saran</span></a>
        <a href="#" class="menu-item" id="logout-link"><i class="fas fa-sign-out-alt"></i><span>Logout</span></a>

    </div>
    <div class="main-content">
        <div class="header">
            <div class="hamburger" onclick="toggleSidebar()"><i class="fas fa-bars"></i></div>
            <h1 class="h4">Waroeng Nusantara</h1>
        </div>
        <div class="content">
            <script>
                document.getElementById('logout-link').addEventListener('click', function(e) {
                    e.preventDefault();
                    if (confirm('Apakah Anda yakin ingin logout?')) {
                        window.location.href = '<?php echo site_url('Login/logout'); ?>';
                    }
                });
            </script>