<?php $this->load->view('templates/header'); ?>

<!-- Menampilkan pesan sukses atau error -->
<?php if ($this->session->flashdata('success')) : ?>
    <div class="alert alert-success">
        <?php echo $this->session->flashdata('success'); ?>
    </div>
<?php endif; ?>
<?php if ($this->session->flashdata('error')) : ?>
    <div class="alert alert-danger">
        <?php echo $this->session->flashdata('error'); ?>
    </div>
<?php endif; ?>
<div class="container-fluid">
    <div class="card shadow">
        <div class="card-body">
            <div class="d-flex justify-content-between">
                <form action="<?= site_url('Meja'); ?>" method="get" class="form-inline mb-3">
                    <input type="text" name="search" class="form-control mr-2" placeholder="Cari meja..." value="<?= isset($search) ? $search : '' ?>">
                    <button type="submit" class="btn btn-primary">Cari</button>
                </form>

                <button type="button" class="btn btn-success" data-toggle="modal" data-target="#tambahMejaModal">Tambah Meja</button>
            </div>
            <div class="table-responsive">
                <table class="table table-bordered">
                    <thead class="thead-light text-center">
                        <tr>
                            <th>Nomor Meja</th>
                            <th>Kapasitas (Orang)</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (empty($meja)) : ?>
                            <tr>
                                <td colspan="3" class="text-center">Data meja tidak tersedia.</td>
                            </tr>
                        <?php else : ?>
                            <?php foreach ($meja as $m) : ?>
                                <tr>
                                    <td><?= $m->nomor_meja ?></td>
                                    <td><?= $m->kapasitas ?></td>
                                    <td>
                                        <button type="button" class="btn btn-warning" data-toggle="modal" data-target="#editMejaModal" data-id="<?= $m->id_meja ?>" data-nomor_meja="<?= $m->nomor_meja ?>" data-kapasitas="<?= $m->kapasitas ?>">Edit</button>
                                        <button type="button" class="btn btn-danger" data-toggle="modal" data-target="#hapusMejaModal" data-id="<?= $m->id_meja ?>">Hapus</button>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<!-- Modal Tambah Meja -->
<div class="modal fade" id="tambahMejaModal" tabindex="-1" role="dialog" aria-labelledby="tambahMejaModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="tambahMejaModalLabel">Tambah Meja</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <form action="<?= site_url('Meja/tambah'); ?>" method="post">
                    <div class="form-group">
                        <label for="nomor_meja">Nomor Meja</label>
                        <input type="text" class="form-control" id="nomor_meja" name="nomor_meja" required>
                    </div>
                    <div class="form-group">
                        <label for="kapasitas">Kapasitas (Orang)</label>
                        <input type="text" class="form-control" id="kapasitas" name="kapasitas" required>
                    </div>
                    <button type="submit" class="btn btn-primary">Simpan</button>
                </form>
            </div>
        </div>
    </div>
</div>

<!-- Modal Edit Meja -->
<div class="modal fade" id="editMejaModal" tabindex="-1" role="dialog" aria-labelledby="editMejaModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="editMejaModalLabel">Edit Meja</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <form action="<?= site_url('Meja/edit') ?>" method="post">
                    <input type="hidden" name="id_meja" id="id_meja" value="">
                    <div class="form-group">
                        <label for="nomor_meja">Nomor Meja</label>
                        <input type="text" class="form-control" id="edit_nomor_meja" name="nomor_meja" required>
                    </div>
                    <div class="form-group">
                        <label for="kapasitas">Kapasitas (Orang)</label>
                        <input type="text" class="form-control" id="edit_kapasitas" name="kapasitas" required>
                    </div>
                    <button type="submit" class="btn btn-primary">Simpan</button>
                </form>
            </div>
        </div>
    </div>
</div>

<!-- Modal Hapus Meja -->
<div class="modal fade" id="hapusMejaModal" tabindex="-1" role="dialog" aria-labelledby="hapusMejaModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="hapusMejaModalLabel">Konfirmasi Hapus Meja</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                Apakah Anda yakin ingin menghapus meja ini?
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Batal</button>
                <a href="#" class="btn btn-danger" id="btn-delete">Hapus</a>
            </div>
        </div>
    </div>
</div>

<script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
<script>
    $(document).ready(function() {
        $('#editMejaModal').on('show.bs.modal', function(event) {
            var button = $(event.relatedTarget);
            var id = button.data('id');
            var nomor_meja = button.data('nomor_meja');
            var kapasitas = button.data('kapasitas');

            var modal = $(this);
            modal.find('.modal-body #id_meja').val(id);
            modal.find('.modal-body #edit_nomor_meja').val(nomor_meja);
            modal.find('.modal-body #edit_kapasitas').val(kapasitas);
        });

        $('#hapusMejaModal').on('show.bs.modal', function(event) {
            var button = $(event.relatedTarget);
            var id = button.data('id');
            var modal = $(this);
            modal.find('#btn-delete').attr('href', '<?= site_url('Meja/hapus/') ?>' + id);
        });
    });
</script>
<?php $this->load->view('templates/footer'); ?>