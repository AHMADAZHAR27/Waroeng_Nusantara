<?php $this->load->view('templates/header'); ?>



<!-- Menampilkan pesan sukses atau error -->
<?php if ($this->session->flashdata('success')) : ?>
    <div class="alert alert-success">
        <?php echo $this->session->flashdata('success'); ?>
    </div>
<?php endif; ?>
<?php if ($this->session->flashdata('error')) : ?>
    <div class="alert alert-danger">
        <?php echo $this->session->flashdata('error'); ?>
    </div>
<?php endif; ?>
<div class="container-fluid">
    <div class="card shadow">
        <div class="card-body">
            <div class="d-flex justify-content-between">
                <form action="<?= site_url('KritikSaran'); ?>" method="get" class="form-inline mb-3">
                    <input type="text" name="search" class="form-control mr-2" placeholder="Cari kritik atau saran..." value="<?= isset($search) ? $search : '' ?>">
                    <button type="submit" class="btn btn-primary">Cari</button>
                </form>
            </div>

            <div class="table-responsive">
                <table class="table table-bordered">
                    <thead class="thead-light text-center">
                        <tr>
                            <th>Nama Pelanggan</th>
                            <th>Email</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (empty($kritik_saran)) : ?>
                            <tr>
                                <td colspan="2" class="text-center">Data kritik dan saran tidak tersedia.</td>
                            </tr>
                        <?php else : ?>
                            <?php foreach ($kritik_saran as $ks) : ?>
                                <tr>
                                    <td><?= $ks->nama_pelanggan ?></td>
                                    <td><?= $ks->email ?></td>
                                    <td>
                                        <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#detailKritikSaranModal" data-nama_pelanggan="<?= $ks->nama_pelanggan ?>" data-email="<?= $ks->email ?>" data-kritik_saran="<?= $ks->kritik_saran ?>" data-tanggal="<?= $ks->tanggal ?>" data-waktu="<?= $ks->waktu ?>">Detail</button>
                                        <button type="button" class="btn btn-danger" data-toggle="modal" data-target="#hapusKritikSaranModal" data-id="<?= $ks->id ?>">Hapus</button>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<!-- Modal Tambah Kritik dan Saran -->
<div class="modal fade" id="tambahKritikSaranModal" tabindex="-1" role="dialog" aria-labelledby="tambahKritikSaranModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="tambahKritikSaranModalLabel">Tambah Kritik dan Saran</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <form action="<?= site_url('KritikSaran/tambah'); ?>" method="post">
                    <div class="form-group">
                        <label for="nama_pelanggan">Nama Pelanggan</label>
                        <input type="text" class="form-control" id="nama_pelanggan" name="nama_pelanggan" required>
                    </div>
                    <div class="form-group">
                        <label for="email">Email</label>
                        <input type="email" class="form-control" id="email" name="email" required>
                    </div>
                    <div class="form-group">
                        <label for="kritik_saran">Kritik dan Saran</label>
                        <textarea class="form-control" id="kritik_saran" name="kritik_saran" rows="3" required></textarea>
                    </div>
                    <button type="submit" class="btn btn-primary">Simpan</button>
                </form>
            </div>
        </div>
    </div>
</div>

<!-- Modal Detail Kritik dan Saran -->
<div class="modal fade" id="detailKritikSaranModal" tabindex="-1" role="dialog" aria-labelledby="detailKritikSaranModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="detailKritikSaranModalLabel">Detail Kritik dan Saran</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <div class="form-group">
                    <label for="detail_nama_pelanggan">Nama Pelanggan</label>
                    <input type="text" class="form-control" id="detail_nama_pelanggan" readonly>
                </div>
                <div class="form-group">
                    <label for="detail_email">Email</label>
                    <input type="email" class="form-control" id="detail_email" readonly>
                </div>
                <div class="form-group">
                    <label for="detail_kritik_saran">Kritik dan Saran</label>
                    <textarea class="form-control" id="detail_kritik_saran" rows="3" readonly></textarea>
                </div>
                <div class="form-group">
                    <label for="detail_tanggal">Tanggal</label>
                    <input type="text" class="form-control" id="detail_tanggal" readonly>
                </div>
                <div class="form-group">
                    <label for="detail_waktu">Waktu</label>
                    <input type="text" class="form-control" id="detail_waktu" readonly>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Modal Edit Kritik dan Saran -->
<div class="modal fade" id="editKritikSaranModal" tabindex="-1" role="dialog" aria-labelledby="editKritikSaranModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="editKritikSaranModalLabel">Edit Kritik dan Saran</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <form action="<?= site_url('KritikSaran/edit') ?>" method="post">
                    <input type="hidden" name="id" id="id" value="">
                    <div class="form-group">
                        <label for="nama_pelanggan">Nama Pelanggan</label>
                        <input type="text" class="form-control" id="edit_nama_pelanggan" name="nama_pelanggan" required>
                    </div>
                    <div class="form-group">
                        <label for="email">Email</label>
                        <input type="email" class="form-control" id="edit_email" name="email" required>
                    </div>
                    <div class="form-group">
                        <label for="kritik_saran">Kritik dan Saran</label>
                        <textarea class="form-control" id="edit_kritik_saran" name="kritik_saran" rows="3" required></textarea>
                    </div>
                    <button type="submit" class="btn btn-primary">Simpan</button>
                </form>
            </div>
        </div>
    </div>
</div>

<!-- Modal Hapus Kritik dan Saran -->
<div class="modal fade" id="hapusKritikSaranModal" tabindex="-1" role="dialog" aria-labelledby="hapusKritikSaranModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="hapusKritikSaranModalLabel">Konfirmasi Hapus Kritik dan Saran</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                Apakah Anda yakin ingin menghapus kritik dan saran ini?
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Batal</button>
                <a href="#" class="btn btn-danger" id="btn-delete">Hapus</a>
            </div>
        </div>
    </div>
</div>

<script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
<script>
    $(document).ready(function() {
        $('#editKritikSaranModal').on('show.bs.modal', function(event) {
            var button = $(event.relatedTarget);
            var id = button.data('id');
            var nama_pelanggan = button.data('nama_pelanggan');
            var email = button.data('email');
            var kritik_saran = button.data('kritik_saran');

            var modal = $(this);
            modal.find('.modal-body #id').val(id);
            modal.find('.modal-body #edit_nama_pelanggan').val(nama_pelanggan);
            modal.find('.modal-body #edit_email').val(email);
            modal.find('.modal-body #edit_kritik_saran').val(kritik_saran);
        });

        $('#hapusKritikSaranModal').on('show.bs.modal', function(event) {
            var button = $(event.relatedTarget);
            var id = button.data('id');
            var modal = $(this);
            modal.find('#btn-delete').attr('href', '<?= site_url('KritikSaran/hapus/') ?>' + id);
        });

        $('#detailKritikSaranModal').on('show.bs.modal', function(event) {
            var button = $(event.relatedTarget);
            var nama_pelanggan = button.data('nama_pelanggan');
            var email = button.data('email');
            var kritik_saran = button.data('kritik_saran');
            var tanggal = button.data('tanggal');
            var waktu = button.data('waktu');

            var modal = $(this);
            modal.find('.modal-body #detail_nama_pelanggan').val(nama_pelanggan);
            modal.find('.modal-body #detail_email').val(email);
            modal.find('.modal-body #detail_kritik_saran').val(kritik_saran);
            modal.find('.modal-body #detail_tanggal').val(tanggal);
            modal.find('.modal-body #detail_waktu').val(waktu);
        });
    });
</script>

<?php $this->load->view('templates/footer'); ?>