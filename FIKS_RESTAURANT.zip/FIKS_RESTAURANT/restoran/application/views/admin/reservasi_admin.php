<?php $this->load->view('templates/header'); ?>

<?php if ($this->session->flashdata('success')) : ?>
    <div class="alert alert-success">
        <?php echo $this->session->flashdata('success'); ?>
    </div>
<?php endif; ?>
<?php if ($this->session->flashdata('error')) : ?>
    <div class="alert alert-danger">
        <?php echo $this->session->flashdata('error'); ?>
    </div>
<?php endif; ?>

<div class="container-fluid">
    <div class="card shadow">
        <div class="card-body">
            <div class="d-flex justify-content-between">
                <form action="<?php echo site_url('ReservasiAdmin'); ?>" method="get" class="form-inline">
                    <div class="form-group mb-2">
                        <input type="text" id="search" name="search" class="form-control" placeholder="Cari Reservasi..." value="<?php echo isset($search) ? $search : ''; ?>">
                    </div>
                    <button type="submit" class="btn btn-primary mb-2 ml-2">Cari</button>
                </form>
            </div>
            <div class="table-responsive" style="overflow-x: auto;">
                <table class="table table-bordered mt-3" style="min-width: 1000px;">
                    <thead class="thead-secondary">
                        <tr>
                            <th>Kode Pembayaran</th>
                            <th>Nama</th>
                            <th>No HP</th>
                            <th>Tanggal Reservasi</th>
                            <th>Meja</th>
                            <th>Total Pembayaran</th>
                            <th>Status Pembayaran</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (empty($reservasi)) : ?>
                            <tr>
                                <td colspan="8" class="text-center">Data yang anda cari tidak ada, <a href="<?php echo site_url('ReservasiAdmin'); ?>">kembali cari</a></td>
                            </tr>
                        <?php else : ?>
                            <?php foreach ($reservasi as $r) : ?>
                                <tr>
                                    <td><?php echo $r->kode_pembayaran; ?></td>
                                    <td><?php echo $r->nama; ?></td>
                                    <td><?php echo $r->no_hp; ?></td>
                                    <td><?php echo $r->tanggal_reservasi; ?></td>
                                    <td><?php echo $r->nomor_meja; ?></td>
                                    <td>Rp. <?php echo number_format($r->total_pembayaran, 0, ',', '.'); ?></td>
                                    <td><?php echo $r->status_pembayaran; ?></td>
                                    <td>
                                        <button class="btn btn-info btn-detail" data-id="<?php echo $r->id_reservasi; ?>">Detail</button>
                                        <button class="btn btn-warning btn-edit" data-id="<?php echo $r->id_reservasi; ?>">Edit</button>
                                        <button class="btn btn-danger btn-delete" data-id="<?php echo $r->id_reservasi; ?>">Hapus</button>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>


<!-- Modal untuk Detail -->
<div class="modal fade" id="detailModal" tabindex="-1" role="dialog" aria-labelledby="detailModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="detailModalLabel">Detail Pesanan</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <table class="table table-bordered">
                    <thead>
                        <tr>
                            <th>Nama Menu</th>
                            <th>Jumlah</th>
                            <th>Harga</th>
                        </tr>
                    </thead>
                    <tbody id="detailMenuTable">
                        <!-- Detail akan dimuat di sini -->
                    </tbody>
                </table>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Tutup</button>
            </div>
        </div>
    </div>
</div>

<!-- Modal untuk Edit -->
<div class="modal fade" id="editModal" tabindex="-1" role="dialog" aria-labelledby="editModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="editModalLabel">Edit Status Pembayaran</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <form id="editForm" method="post" action="">
                    <div class="form-group">
                        <label for="status_pembayaran">Status Pembayaran</label>
                        <select class="form-control" id="status_pembayaran" name="status_pembayaran" required>
                            <option value="Belum Dibayar">Belum Dibayar</option>
                            <option value="DP Dibayar">DP Dibayar</option>
                            <option value="Lunas">Lunas</option>
                            <option value="Selesai">Selesai</option>
                        </select>
                    </div>
                    <button type="submit" class="btn btn-primary">Simpan Perubahan</button>
                </form>
            </div>
        </div>
    </div>
</div>

<!-- JS -->
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script> <!-- Versi lengkap jQuery -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
<script>
    $(document).ready(function() {
        $('.btn-detail').click(function() {
            const id = $(this).data('id');
            console.log('Detail button clicked, id:', id); // Tambahkan log untuk memastikan event klik berjalan
            $.ajax({
                url: '<?php echo site_url("ReservasiAdmin/get_detail_menu/"); ?>' + id,
                method: 'GET',
                success: function(data) {
                    console.log('Data received:', data); // Tambahkan log untuk memastikan data diterima
                    const menu = JSON.parse(data);
                    let html = '';
                    menu.forEach(function(item) {
                        html += `
                            <tr>
                                <td>${item.nama_menu}</td>
                                <td>${item.jumlah}</td>
                                <td>Rp. ${parseInt(item.harga).toLocaleString()}</td>
                            </tr>
                        `;
                    });
                    $('#detailMenuTable').html(html);
                    $('#detailModal').modal('show');
                },
                error: function(xhr, status, error) {
                    console.error('Error:', error); // Tambahkan log untuk error handling
                    alert('Terjadi kesalahan saat mengambil data detail.');
                }
            });
        });

        $('.btn-edit').click(function() {
            const id = $(this).data('id');
            console.log('Edit button clicked, id:', id); // Tambahkan log untuk memastikan event klik berjalan
            $.ajax({
                url: '<?php echo site_url("ReservasiAdmin/get_reservasi/"); ?>' + id,
                method: 'GET',
                success: function(data) {
                    console.log('Data received:', data); // Tambahkan log untuk memastikan data diterima
                    const reservasi = JSON.parse(data);
                    $('#status_pembayaran').val(reservasi.status_pembayaran);
                    $('#editForm').attr('action', '<?php echo site_url("ReservasiAdmin/update_reservasi/"); ?>' + id);
                    $('#editModal').modal('show');
                },
                error: function(xhr, status, error) {
                    console.error('Error:', error); // Tambahkan log untuk error handling
                    alert('Terjadi kesalahan saat mengambil data reservasi.');
                }
            });
        });

        $('.btn-delete').click(function() {
            if (confirm('Apakah Anda yakin ingin menghapus data ini?')) {
                const id = $(this).data('id');
                window.location.href = '<?php echo site_url("ReservasiAdmin/delete_reservasi/"); ?>' + id;
            }
        });
    });
</script>
<?php $this->load->view('templates/footer'); ?>