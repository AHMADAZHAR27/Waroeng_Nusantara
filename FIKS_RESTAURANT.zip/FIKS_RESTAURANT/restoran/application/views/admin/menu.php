<?php $this->load->view('templates/header'); ?>
<?php if ($this->session->flashdata('login_success')) : ?>
    <div class="alert alert-success" role="alert">
        <?php echo $this->session->flashdata('login_success'); ?>
    </div>
<?php endif; ?>

<!-- Menampilkan pesan sukses atau error -->
<?php if ($this->session->flashdata('success')) : ?>
    <div class="alert alert-success">
        <?php echo $this->session->flashdata('success'); ?>
    </div>
<?php endif; ?>
<?php if ($this->session->flashdata('error')) : ?>
    <div class="alert alert-danger">
        <?php echo $this->session->flashdata('error'); ?>
    </div>
<?php endif; ?>

<link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
<div class="container-fluid">
    <div class="card shadow">
        <div class="card-body">
            <div class="d-flex justify-content-between">
                <form action="<?= site_url('Menu/search'); ?>" method="get" class="form-inline mb-3">
                    <input type="text" name="q" class="form-control mr-2" placeholder="Cari menu...">
                    <button type="submit" class="btn btn-primary">Cari</button>
                </form>
                <button type="button" class="btn btn-success" data-toggle="modal" data-target="#tambahMenuModal">Tambah Menu</button>
            </div>
            <div class="table-responsive">
                <table class="table table-bordered">
                    <thead class="thead-light text-center">
                        <tr>
                            <th>Nama Menu</th>
                            <th>Detail Menu</th>
                            <th>Kategori</th>
                            <th>Stok</th>
                            <th>Harga</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($menus as $menu) : ?>
                            <tr>
                                <td><?= $menu->nama_menu ?></td>
                                <td><?= $menu->detail_menu ?></td>
                                <td><?= $menu->kategori ?></td>
                                <td><?= $menu->stok ?></td>
                                <td><?= $menu->harga ?></td>
                                <td>
                                    <?php $gambar = !empty($menu->gambar_menu) ? base_url($menu->gambar_menu) : ''; ?>
                                    <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#gambarMenuModal" data-gambar="<?= $gambar ?>">Gambar</button>
                                    <button type="button" class="btn btn-warning" data-toggle="modal" data-target="#editMenuModal" data-id="<?= $menu->id_menu ?>" data-nama_menu="<?= $menu->nama_menu ?>" data-detail_menu="<?= $menu->detail_menu ?>" data-kategori="<?= $menu->kategori ?>" data-stok="<?= $menu->stok ?>" data-harga="<?= $menu->harga ?>" data-old_gambar="<?= $menu->gambar_menu ?>">Edit</button>
                                    <button type="button" class="btn btn-danger" data-toggle="modal" data-target="#hapusMenuModal" data-id="<?= $menu->id_menu ?>">Hapus</button>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>


<!-- Modal Tambah Menu -->
<div class="modal fade" id="tambahMenuModal" tabindex="-1" role="dialog" aria-labelledby="tambahMenuModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="tambahMenuModalLabel">Tambah Menu</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <form action="<?= site_url('Menu/tambah'); ?>" method="post" enctype="multipart/form-data">
                    <div class="form-group">
                        <label for="nama_menu">Nama Menu</label>
                        <input type="text" class="form-control" id="nama_menu" name="nama_menu" required>
                    </div>
                    <div class="form-group">
                        <label for="detail_menu">Detail Menu</label>
                        <textarea class="form-control" id="detail_menu" name="detail_menu" rows="3" required></textarea>
                    </div>
                    <div class="form-group">
                        <label for="kategori">Kategori</label>
                        <select class="form-control" id="kategori" name="kategori" required>
                            <option value="Makanan">Makanan</option>
                            <option value="Minuman">Minuman</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="stok">Stok</label>
                        <select class="form-control" id="stok" name="stok" required>
                            <option>-</option>
                            <option value="Tersedia">Tersedia</option>
                            <option value="Habis">Habis</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="harga">Harga</label>
                        <input type="text" class="form-control" id="harga" name="harga" required>
                    </div>
                    <div class="form-group">
                        <label for="gambar_menu">Upload Gambar</label>
                        <input type="file" class="form-control" id="gambar_menu" name="userfile" size="20" onchange="previewImage(event)">
                        <small class="form-text text-danger">Format gambar harus jpeg, jpg, png dan max file 5 MB. Gambar ukuran harus 1 banding 1.</small>
                    </div>
                    <div class="form-group text-center">
                        <img id="image-preview" src="" alt="Image Preview" class="img-thumbnail" style="display:none; width:200px; height:200px; object-fit:cover;">
                    </div>
                    <button type="submit" class="btn btn-primary">Simpan</button>
                </form>
            </div>
        </div>
    </div>
</div>

<!-- Modal Gambar Menu -->
<div class="modal fade" id="gambarMenuModal" tabindex="-1" role="dialog" aria-labelledby="gambarMenuModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="gambarMenuModalLabel">Gambar Menu</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body text-center">
                <img id="gambar-menu-preview" src="" alt="Gambar Menu" class="img-fluid" style="display:none; width:300px; height:300px; object-fit:cover;">
                <p id="gambar-not-available" style="display:none;">Belum ada gambar untuk menu ini.</p>
            </div>
        </div>
    </div>
</div>

<!-- Modal Edit Menu -->
<div class="modal fade" id="editMenuModal" tabindex="-1" role="dialog" aria-labelledby="editMenuModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="editMenuModalLabel">Edit Menu</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <form action="<?= site_url('Menu/edit') ?>" method="post" enctype="multipart/form-data">
                    <input type="hidden" name="id_menu" id="id_menu" value="">
                    <input type="hidden" name="old_gambar" id="old_gambar" value="">
                    <div class="form-group">
                        <label for="edit_nama_menu">Nama Menu</label>
                        <input type="text" class="form-control" id="edit_nama_menu" name="nama_menu" required>
                    </div>
                    <div class="form-group">
                        <label for="edit_detail_menu">Detail Menu</label>
                        <textarea class="form-control" id="edit_detail_menu" name="detail_menu" rows="3" required></textarea>
                    </div>
                    <div class="form-group">
                        <label for="edit_kategori">Kategori</label>
                        <select class="form-control" id="edit_kategori" name="kategori" required>
                            <option value="Makanan">Makanan</option>
                            <option value="Minuman">Minuman</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="edit_stok">Stok</label>
                        <select class="form-control" id="edit_stok" name="stok" required>
                            <option>-</option>
                            <option value="Tersedia">Tersedia</option>
                            <option value="Habis">Habis</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="edit_harga">Harga</label>
                        <input type="number" class="form-control" id="edit_harga" name="harga" required>
                    </div>
                    <div class="form-group">
                        <label for="edit_gambar_menu">Upload Gambar</label>
                        <input type="file" class="form-control" id="edit_gambar_menu" name="userfile" size="20" onchange="editPreviewImage(event)">
                        <small class="form-text text-danger">Format gambar harus jpeg, jpg, png dan max file 5 MB. Gambar ukuran harus 1 banding 1.</small>
                    </div>
                    <div class="form-group text-center">
                        <img id="edit_image-preview" src="" alt="Image Preview" class="img-thumbnail" style="display:none; width:200px; height:200px; object-fit:cover;">
                    </div>
                    <button type="submit" class="btn btn-primary">Simpan</button>
                </form>
            </div>
        </div>
    </div>
</div>

<!-- Modal Hapus Menu -->
<div class="modal fade" id="hapusMenuModal" tabindex="-1" role="dialog" aria-labelledby="hapusMenuModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="hapusMenuModalLabel">Konfirmasi Hapus Menu</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                Apakah Anda yakin ingin menghapus menu ini?
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Batal</button>
                <a id="confirmDelete" href="#" class="btn btn-danger">Hapus</a>
            </div>
        </div>
    </div>
</div>

<script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@1.16.1/dist/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>

<script>
    function previewImage(event) {
        var reader = new FileReader();
        reader.onload = function() {
            var output = document.getElementById('image-preview');
            output.src = reader.result;
            output.style.display = 'block';
        }
        reader.readAsDataURL(event.target.files[0]);
    }

    function editPreviewImage(event) {
        var reader = new FileReader();
        reader.onload = function() {
            var output = document.getElementById('edit_image-preview');
            output.src = reader.result;
            output.style.display = 'block';
        }
        reader.readAsDataURL(event.target.files[0]);
    }

    $(document).ready(function() {
        $('#editMenuModal').on('show.bs.modal', function(event) {
            var button = $(event.relatedTarget); // Button that triggered the modal
            var id = button.data('id');
            var nama_menu = button.data('nama_menu');
            var detail_menu = button.data('detail_menu');
            var kategori = button.data('kategori');
            var stok = button.data('stok');
            var harga = button.data('harga');

            var modal = $(this);
            modal.find('.modal-body #id_menu').val(id);
            modal.find('.modal-body #edit_nama_menu').val(nama_menu);
            modal.find('.modal-body #edit_detail_menu').val(detail_menu);
            modal.find('.modal-body #edit_harga').val(harga);
            modal.find('.modal-body #old_gambar').val(button.data('old_gambar'));

            modal.find('.modal-body #edit_kategori option').each(function() {
                $(this).prop('selected', $(this).val() === kategori);
            });

            modal.find('.modal-body #edit_stok option').each(function() {
                $(this).prop('selected', $(this).val() === stok);
            });
        });

        $('#gambarMenuModal').on('show.bs.modal', function(event) {
            var button = $(event.relatedTarget);
            var gambar = button.data('gambar');
            var modal = $(this);
            if (gambar) {
                modal.find('#gambar-menu-preview').attr('src', gambar).show();
                modal.find('#gambar-not-available').hide();
            } else {
                modal.find('#gambar-menu-preview').hide();
                modal.find('#gambar-not-available').show();
            }
        });

        $('#hapusMenuModal').on('show.bs.modal', function(event) {
            var button = $(event.relatedTarget);
            var id = button.data('id');
            var modal = $(this);
            modal.find('#confirmDelete').attr('href', '<?= site_url('Menu/hapus/') ?>' + id);
        });
    });
</script>

<?php $this->load->view('templates/footer'); ?>