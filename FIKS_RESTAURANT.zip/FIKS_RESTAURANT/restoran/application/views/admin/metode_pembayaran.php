<?php $this->load->view('templates/header'); ?>
<!-- Menampilkan pesan sukses atau error -->
<?php if ($this->session->flashdata('success')) : ?>
    <div class="alert alert-success">
        <?php echo $this->session->flashdata('success'); ?>
    </div>
<?php endif; ?>
<?php if ($this->session->flashdata('error')) : ?>
    <div class="alert alert-danger">
        <?php echo $this->session->flashdata('error'); ?>
    </div>
<?php endif; ?>


<div class="container-fluid">
    <div class="card shadow">
        <div class="card-body">
            <div class="d-flex justify-content-between">
                <form action="<?= site_url('MetodePembayaran'); ?>" method="get" class="form-inline mb-3">
                    <input type="text" name="search" class="form-control mr-2" placeholder="Cari metode pembayaran..." value="<?= isset($search) ? $search : '' ?>">
                    <button type="submit" class="btn btn-primary">Cari</button>
                </form>

                <button type="button" class="btn btn-success" data-toggle="modal" data-target="#tambahMetodePembayaranModal">Tambah Metode Pembayaran</button>
            </div>
            <div class="table-responsive">
                <table class="table table-bordered">
                    <thead class="thead-light text-center">
                        <tr>
                            <th>Bank/Merchant</th>
                            <th>Rekening/No. Hp</th>
                            <th>Atas Nama</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (empty($metode_pembayaran)) : ?>
                            <tr>
                                <td colspan="4" class="text-center">Data metode pembayaran tidak tersedia.</td>
                            </tr>
                        <?php else : ?>
                            <?php foreach ($metode_pembayaran as $mp) : ?>
                                <tr>
                                    <td><?= $mp->bank ?></td>
                                    <td><?= $mp->rekening ?></td>
                                    <td><?= $mp->nama_rekening ?></td>
                                    <td>
                                        <button type="button" class="btn btn-warning" data-toggle="modal" data-target="#editMetodePembayaranModal" data-id="<?= $mp->id_mp ?>" data-bank="<?= $mp->bank ?>" data-rekening="<?= $mp->rekening ?>" data-nama_rekening="<?= $mp->nama_rekening ?>">Edit</button>
                                        <button type="button" class="btn btn-danger" data-toggle="modal" data-target="#hapusMetodePembayaranModal" data-id="<?= $mp->id_mp ?>">Hapus</button>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<!-- Modal Tambah Metode Pembayaran -->
<div class="modal fade" id="tambahMetodePembayaranModal" tabindex="-1" role="dialog" aria-labelledby="tambahMetodePembayaranModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="tambahMetodePembayaranModalLabel">Tambah Metode Pembayaran</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <form action="<?= site_url('MetodePembayaran/tambah'); ?>" method="post">
                    <div class="form-group">
                        <label for="bank">Bank/Merchant</label>
                        <input type="text" class="form-control" id="bank" name="bank" required>
                    </div>
                    <div class="form-group">
                        <label for="rekening">Rekening/No. Hp</label>
                        <input type="text" class="form-control" id="rekening" name="rekening" required>
                    </div>
                    <div class="form-group">
                        <label for="nama_rekening">Atas Nama</label>
                        <input type="text" class="form-control" id="nama_rekening" name="nama_rekening" required>
                    </div>
                    <button type="submit" class="btn btn-primary">Simpan</button>
                </form>
            </div>
        </div>
    </div>
</div>

<!-- Modal Edit Metode Pembayaran -->
<div class="modal fade" id="editMetodePembayaranModal" tabindex="-1" role="dialog" aria-labelledby="editMetodePembayaranModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="editMetodePembayaranModalLabel">Edit Metode Pembayaran</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <form action="<?= site_url('MetodePembayaran/edit') ?>" method="post">
                    <input type="hidden" name="id_mp" id="id_mp" value="">
                    <div class="form-group">
                        <label for="bank">Bank/Merchant</label>
                        <input type="text" class="form-control" id="edit_bank" name="bank" required>
                    </div>
                    <div class="form-group">
                        <label for="rekening">Rekening/No. Hp</label>
                        <input type="text" class="form-control" id="edit_rekening" name="rekening" required>
                    </div>
                    <div class="form-group">
                        <label for="nama_rekening">Atas Nama</label>
                        <input type="text" class="form-control" id="edit_nama_rekening" name="nama_rekening" required>
                    </div>
                    <button type="submit" class="btn btn-primary">Simpan</button>
                </form>
            </div>
        </div>
    </div>
</div>

<!-- Modal Hapus Metode Pembayaran -->
<div class="modal fade" id="hapusMetodePembayaranModal" tabindex="-1" role="dialog" aria-labelledby="hapusMetodePembayaranModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="hapusMetodePembayaranModalLabel">Konfirmasi Hapus Metode Pembayaran</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                Apakah Anda yakin ingin menghapus metode pembayaran ini?
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Batal</button>
                <a href="#" class="btn btn-danger" id="btn-delete">Hapus</a>
            </div>
        </div>
    </div>
</div>

<script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
<script>
    $(document).ready(function() {
        $('#editMetodePembayaranModal').on('show.bs.modal', function(event) {
            var button = $(event.relatedTarget);
            var id = button.data('id');
            var bank = button.data('bank');
            var rekening = button.data('rekening');
            var nama_rekening = button.data('nama_rekening');

            var modal = $(this);
            modal.find('.modal-body #id_mp').val(id);
            modal.find('.modal-body #edit_bank').val(bank);
            modal.find('.modal-body #edit_rekening').val(rekening);
            modal.find('.modal-body #edit_nama_rekening').val(nama_rekening);
        });

        $('#hapusMetodePembayaranModal').on('show.bs.modal', function(event) {
            var button = $(event.relatedTarget);
            var id = button.data('id');
            var modal = $(this);
            modal.find('#btn-delete').attr('href', '<?= site_url('MetodePembayaran/hapus/') ?>' + id);
        });
    });
</script>
<?php $this->load->view('templates/footer'); ?>