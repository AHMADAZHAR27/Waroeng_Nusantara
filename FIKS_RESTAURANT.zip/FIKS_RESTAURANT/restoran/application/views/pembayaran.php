<!DOCTYPE html>
<html lang="en">

<head>
    <!-- Metadata dan CSS -->
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <link rel="icon" href="<?php echo base_url('asset/gambar/logo.png'); ?>" type="image/png">
    <title>Restuarant Website</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <link href="https://cdn.jsdelivr.net/npm/remixicon@2.5.0/fonts/remixicon.css" rel="stylesheet" />
    <link rel="stylesheet" href="<?php echo base_url('asset/style.css'); ?>" />
    <style>
        body {
            color: #fff;
        }

        .payment-info {
            max-width: 800px;
            margin: 50px auto;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        .payment-info h2 {
            margin-bottom: 20px;
        }

        .payment-info .btn {
            width: 100%;
        }

        .payment-info .alert {
            margin-top: 20px;
        }

        .payment-info .modal-header,
        .payment-info .modal-footer {
            border: none;
        }

        .copy-invoice-container {
            display: flex;
            align-items: center;
            margin-bottom: 1rem;
        }

        .copy-invoice-container input {
            flex: 1;
            border-top-right-radius: 0;
            border-bottom-right-radius: 0;
        }

        .copy-invoice-container button {
            border-top-left-radius: 0;
            border-bottom-left-radius: 0;
        }

        .highlight-green {
            color: #28a745;
        }

        .table thead th {
            background-color: #6c757d;
            color: #fff;
        }
    </style>
</head>

<body>
    <!-- Header -->
    <header class="header">
        <nav class="nav">
            <div class="container">
                <div class="nav__wrapper">
                    <div class="logo">
                        <h1>RESER<span class="highlight">VASI</span></h1>
                    </div>
                    <div class="navigation">
                        <ul class="nav__menu">
                            <li class="nav__item"><a onclick="window.location.href='<?php echo site_url('Landing'); ?>'" class="nav__link">Home</a></li>
                            <li class="nav__item"><a onclick="window.location.href='<?php echo site_url('Katalog'); ?>'" class="nav__link">Katalog Menu</a></li>
                            <li class="nav__item"><a onclick="window.location.href='<?php echo site_url('Reservasi'); ?>'" class="nav__link">Reservasi</a></li>
                            <li class="nav__item"><a onclick="window.location.href='<?php echo site_url('CekPembayaran'); ?>'" class="nav__link">Cek Pembayaran</a></li>
                            <li class="nav__item"><a onclick="window.location.href='<?php echo site_url('Kritik'); ?>'" class="nav__link">Kritik & Saran</a></li>
                        </ul>
                    </div>
                    <span class="mobile__menu"><i class="ri-menu-line"></i></span>
                </div>
            </div>
        </nav>
    </header>

    <!-- Konten -->
    <div class="container mt-5">
        <?php if ($this->session->flashdata('message')) : ?>
            <div class="alert alert-success" role="alert"><?php echo $this->session->flashdata('message'); ?></div>
        <?php endif; ?>
        <?php if ($this->session->flashdata('error')) : ?>
            <div class="alert alert-danger" role="alert"><?php echo $this->session->flashdata('error'); ?></div>
        <?php endif; ?>

        <h1>Terima Kasih, <?php echo $reservasi->nama; ?> telah melakukan reservasi</h1>
        <div class="copy-invoice-container">
            <input type="text" class="form-control" id="kodePembayaran" value="<?php echo $reservasi->kode_pembayaran; ?>" readonly>
            <button onclick="copyToClipboard()" class="btn btn-primary">Copy Invoice</button>
        </div>

        <h3 class="mt-4">Ringkasan Reservasi</h3>
        <table class="table table-bordered">
            <thead>
                <tr>
                    <th>Nomor Meja</th>
                    <th>Nama Menu</th>
                    <th>Jumlah</th>
                    <th>Harga Satuan</th>
                    <th>Total Harga</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($menu_dipesan as $menu) : ?>
                    <tr>
                        <td>Nomor <?php echo $meja_dipesan->nomor_meja; ?></td>
                        <td><?php echo $menu->nama_menu; ?></td>
                        <td><?php echo $menu->jumlah; ?></td>
                        <td>Rp. <?php echo number_format($menu->harga, 0, ',', '.'); ?></td>
                        <td>Rp. <?php echo number_format($menu->harga * $menu->jumlah, 0, ',', '.'); ?></td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>

        <h4>Dengan Total Pembayaran <span class="highlight-green">Rp. <?= number_format($reservasi->total_pembayaran, 0, ',', '.') ?></span> Atau DP <span class="highlight-green">Rp. <?= number_format($reservasi->total_pembayaran / 2, 0, ',', '.') ?></span></h4>

        <h2 class="mt-4">Silahkan Pilih Metode Pembayaran</h2>
        <table class="table table-bordered table-striped text-white">
            <thead>
                <tr>
                    <th>Bank</th>
                    <th>No. Rekening</th>
                    <th>Atas Nama</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($metode_pembayaran as $metode) : ?>
                    <tr>
                        <td><?php echo $metode->bank; ?></td>
                        <td><?php echo $metode->rekening; ?></td>
                        <td><?php echo $metode->nama_rekening; ?></td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
        <p>Silahkan Screenshot bukti pembayaran anda</p>
        <p>Lalu, lakukan Verifikasi Pembayaran Sesuai Dengan Jenis Pembayaran Yang Anda Pilih </p>
        <p>Pembatalan Transaksi Akan dilakukan jika dalam 1x24 jam tidak dilakukan konfirmasi pembayaran</p>
        <button class="btn btn-success" data-bs-toggle="modal" data-bs-target="#verifikasiModal">Verifikasi Pembayaran</button>
        <a href="<?= site_url('Landing') ?>" class="btn btn-secondary">Kembali Ke Halaman Awal</a>
    </div>

    <!-- Modal Verifikasi Pembayaran -->
    <div class="modal fade" id="verifikasiModal" tabindex="-1" aria-labelledby="verifikasiModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="verifikasiModalLabel" style="color:black;">Verifikasi Pembayaran</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <form action="<?= site_url('Pembayaran/verifikasi') ?>" method="post" enctype="multipart/form-data">
                        <div class="mb-3">
                            <label for="pembayaran_tipe" class="form-label">Jenis Pembayaran</label>
                            <select class="form-select" id="pembayaran_tipe" name="pembayaran_tipe" required>
                                <option value="Belum Dibayar">Belum Dibayar</option>
                                <option value="DP">DP</option>
                                <option value="Lunas">Lunas</option>
                            </select>
                        </div>
                        <div class="mb-3">
                            <label for="bukti_pembayaran" class="form-label">Bukti Pembayaran</label>
                            <input type="file" class="form-control" id="bukti_pembayaran" name="bukti_pembayaran" required>
                        </div>
                        <input type="hidden" name="kode_pembayaran" value="<?= $reservasi->kode_pembayaran ?>">
                        <button type="submit" class="btn btn-primary">Kirim</button>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <script>
        function copyToClipboard() {
            var copyText = document.getElementById("kodePembayaran");
            navigator.clipboard.writeText(copyText.value).then(function() {
                alert("Kode pembayaran telah disalin: " + copyText.value);
            }, function(err) {
                console.error('Async: Could not copy text: ', err);
            });
        }
    </script>

    <!-- =========== footer start ============ -->
    <footer class="section footer">
        <div class="container">
            <div class="footer__wrapper">
                <div class="footer__logo">
                    <div class="logo">
                        <h1>Waroeng<span class="highlight">Nusantara</span></h1>
                    </div>
                    <button class="btn btn-secondary" onclick="window.location.href='<?php echo site_url('Login'); ?>'">Admin</button>
                </div>

                <div class="footer__box">
                    <h3 class="footer__link-title">Location</h3>
                    <ul class="footer__menu">
                        <li class="footer__menu-item">
                            <a href="#about" class="footer__link">Yogyakarta</a>
                        </li>
                    </ul>
                </div>

                <div class="footer__box">
                    <h3 class="footer__link-title">Services</h3>
                    <ul class="footer__menu">
                        <li class="footer__menu-item">
                            <a href="#about" class="footer__link">Online reservasi</a>
                        </li>
                        <li class="footer__menu-item">
                            <a href="#" class="footer__link">Fast Respon</a>
                        </li>
                        <li class="footer__menu-item">
                            <a href="#" class="footer__link">Pre-Reservation</a>
                        </li>
                        <li class="footer__menu-item">
                            <a href="#" class="footer__link">Halal</a>
                        </li>
                    </ul>
                </div>

                <div class="footer__box">
                    <h3 class="footer__link-title">Jam Oprasional</h3>
                    <ul class="footer__menu">
                        <li class="footer__menu-item">
                            <a href="#menu" class="footer__link">Senin-Jum'at: 08:00-22:00</a>
                        </li>
                        <li class="footer__menu-item">
                            <a href="#blog" class="footer__link">Sabtu: 10:00-00:00</a>
                        </li>
                        <li class="footer__menu-item">
                            <a href="#about" class="footer__link">Minggu: 10:00-20:00</a>
                        </li>
                    </ul>
                </div>

                <div class="footer__box">
                    <h3 class="footer__link-title">Social</h3>
                    <ul class="footer__menu">
                        <li class="footer__menu-item">
                            <a href="#" class="footer__link">Facebook</a>
                        </li>
                        <li class="footer__menu-item">
                            <a href="#" class="footer__link">Instagram</a>
                        </li>
                        <li class="footer__menu-item">
                            <a href="#" class="footer__link">Linkedin</a>
                        </li>
                        <li class="footer__menu-item">
                            <a href="#" class="footer__link">Twitter</a>
                        </li>
                    </ul>
                </div>
            </div>

            <p class="footer__copyright">
                © 2024 Kelompok_3 All Rights Reserved.
            </p>
        </div>
    </footer>
    <!-- =========== footer end ============ -->
    <!-- main js file -->
    <script src="<?php echo base_url('asset/app.js'); ?>"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
</body>

</html>