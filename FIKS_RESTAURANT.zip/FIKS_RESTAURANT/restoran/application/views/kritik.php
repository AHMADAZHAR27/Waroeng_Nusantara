<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <link rel="icon" href="<?php echo base_url('asset/gambar/logo.png'); ?>" type="image/png">
    <title>Restuarant Website</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <!-- remix icon cdn -->
    <link href="https://cdn.jsdelivr.net/npm/remixicon@2.5.0/fonts/remixicon.css" rel="stylesheet" />

    <!-- custom css file  -->
    <link rel="stylesheet" href="<?php echo base_url('asset/style.css'); ?>" />
    <style>
        .kritik-form {
            margin-top: 10px;
        }

        .kritik-form h2 {
            margin-bottom: 20px;
        }

        .kritik-form .form-control {
            margin-bottom: 15px;
        }

        .kritik-form .btn {
            width: 100%;
        }
    </style>
    </style>
</head>

<body>
    <!-- =========== header start ============ -->
    <header class="header">
        <nav class="nav">
            <div class="container">
                <div class="nav__wrapper">
                    <div class="logo">
                        <h1>RESER<span class="highlight">VASI</span></h1>
                    </div>

                    <div class="navigation">
                        <ul class="nav__menu">
                            <li class="nav__item">
                                <a onclick="window.location.href='<?php echo site_url('Landing'); ?>'" class="nav__link">Home</a>
                            </li>
                            <li class="nav__item">
                                <a onclick="window.location.href='<?php echo site_url('Katalog'); ?>'" class="nav__link">Katalog Menu</a>
                            </li>
                            <li class="nav__item">
                                <a onclick="window.location.href='<?php echo site_url('Reservasi'); ?>'" class="nav__link">Reservasi</a>
                            </li>
                            <li class="nav__item">
                                <a onclick="window.location.href='<?php echo site_url('CekPembayaran'); ?>'" class="nav__link">Cek Pembayaran</a>
                            </li>
                            <li class="nav__item">
                                <a onclick="window.location.href='<?php echo site_url('Kritik'); ?>'" class="nav__link">Kritik & Saran</a>
                            </li>
                        </ul>
                    </div>

                    <span class="mobile__menu"><i class="ri-menu-line"></i></span>
                </div>
            </div>
        </nav>
    </header>

    <!-- =========== header end ============ -->
    <div class="container">
        <div class="kritik-form">
            <?php if ($this->session->flashdata('message')) : ?>
                <div class="alert alert-success">
                    <?php echo $this->session->flashdata('message'); ?>
                </div>
            <?php endif; ?>
            <h2>Kritik</h2>
            <p>Kritik yang anda berikan akan sangat berguna untuk peningkatan kualitas dari usaha kami.</p>
            <form action="<?php echo site_url('kritik/submit'); ?>" method="post">
                <div class="row">
                    <div class="col-md-6">
                        <input type="text" class="form-control" name="nama_pelanggan" placeholder="Nama Anda" required>
                    </div>
                    <div class="col-md-6">
                        <input type="email" class="form-control" name="email" placeholder="Email" required>
                    </div>
                </div>
                <div class="form-group">
                    <textarea class="form-control" name="kritik_saran" rows="5" placeholder="Kritik & Saran....." required></textarea>
                </div>
                <button type="submit" class="btn btn-secondary">Kirim Kritik & Saran</button>
            </form>
        </div>
    </div>
    <!-- =========== footer start ============ -->
    <footer class="section footer">
        <div class="container">
            <div class="footer__wrapper">
                <div class="footer__logo">
                    <div class="logo">
                        <h1>Waroeng<span class="highlight">Nusantara</span></h1>
                    </div>
                    <button class="btn btn-secondary" onclick="window.location.href='<?php echo site_url('Login'); ?>'">Admin</button>
                </div>

                <div class="footer__box">
                    <h3 class="footer__link-title">Location</h3>
                    <ul class="footer__menu">
                        <li class="footer__menu-item">
                            <a href="#about" class="footer__link">Yogyakarta</a>
                        </li>
                    </ul>
                </div>

                <div class="footer__box">
                    <h3 class="footer__link-title">Services</h3>
                    <ul class="footer__menu">
                        <li class="footer__menu-item">
                            <a href="#about" class="footer__link">Online reservasi</a>
                        </li>
                        <li class="footer__menu-item">
                            <a href="#" class="footer__link">Fast Respon</a>
                        </li>
                        <li class="footer__menu-item">
                            <a href="#" class="footer__link">Pre-Reservation</a>
                        </li>
                        <li class="footer__menu-item">
                            <a href="#" class="footer__link">Halal</a>
                        </li>
                    </ul>
                </div>

                <div class="footer__box">
                    <h3 class="footer__link-title">Jam Oprasional</h3>
                    <ul class="footer__menu">
                        <li class="footer__menu-item">
                            <a href="#menu" class="footer__link">Senin-Jum'at: 08:00-22:00</a>
                        </li>
                        <li class="footer__menu-item">
                            <a href="#blog" class="footer__link">Sabtu: 10:00-00:00</a>
                        </li>
                        <li class="footer__menu-item">
                            <a href="#about" class="footer__link">Minggu: 10:00-20:00</a>
                        </li>
                    </ul>
                </div>

                <div class="footer__box">
                    <h3 class="footer__link-title">Social</h3>
                    <ul class="footer__menu">
                        <li class="footer__menu-item">
                            <a href="#" class="footer__link">Facebook</a>
                        </li>
                        <li class="footer__menu-item">
                            <a href="#" class="footer__link">Instagram</a>
                        </li>
                        <li class="footer__menu-item">
                            <a href="#" class="footer__link">Linkedin</a>
                        </li>
                        <li class="footer__menu-item">
                            <a href="#" class="footer__link">Twitter</a>
                        </li>
                    </ul>
                </div>
            </div>

            <p class="footer__copyright">
                © 2024 Kelompok_3 All Rights Reserved.
            </p>
        </div>
    </footer>
    <!-- =========== footer end ============ -->

    <!-- main js file -->
    <script src="<?php echo base_url('asset/app.js'); ?>"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
</body>

</html>