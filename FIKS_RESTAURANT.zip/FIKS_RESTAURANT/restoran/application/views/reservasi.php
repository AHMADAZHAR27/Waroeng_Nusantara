<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Restuarant Website</title>
    <link rel="icon" href="<?php echo base_url('asset/gambar/logo.png'); ?>" type="image/png">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <!-- remix icon cdn -->
    <link href="https://cdn.jsdelivr.net/npm/remixicon@2.5.0/fonts/remixicon.css" rel="stylesheet" />

    <!-- custom css file  -->
    <link rel="stylesheet" href="<?php echo base_url('asset/style.css'); ?>" />
    <style>
        body {
            color: #fff;
        }

        .form-reservasi {
            max-width: 600px;
            margin: 50px auto;
        }

        .form-reservasi h2,
        .form-reservasi h4 {
            margin-bottom: 20px;
        }

        .form-reservasi .form-control {
            margin-bottom: 15px;
        }

        .form-reservasi .btn {
            width: 100%;
        }

        .order-summary {
            margin-top: 50px;
        }

        .order-summary h4 {
            margin-bottom: 20px;
        }

        .order-summary .order-item {
            display: flex;
            justify-content: space-between;
            margin-bottom: 10px;
        }

        .order-summary .order-total {
            margin-top: 20px;
            font-weight: bold;
        }

        .highlight-green {
            color: green;
        }
    </style>
</head>

<body>
    <!-- =========== header start ============ -->
    <header class="header">
        <nav class="nav">
            <div class="container">
                <div class="nav__wrapper">
                    <div class="logo">
                        <h1>RESER<span class="highlight">VASI</span></h1>
                    </div>

                    <div class="navigation">
                        <ul class="nav__menu">
                            <li class="nav__item">
                                <a onclick="window.location.href='<?php echo site_url('Landing'); ?>'" class="nav__link">Home</a>
                            </li>
                            <li class="nav__item">
                                <a onclick="window.location.href='<?php echo site_url('Katalog'); ?>'" class="nav__link">Katalog Menu</a>
                            </li>
                            <li class="nav__item">
                                <a onclick="window.location.href='<?php echo site_url('Reservasi'); ?>'" class="nav__link">Reservasi</a>
                            </li>
                            <li class="nav__item">
                                <a onclick="window.location.href='<?php echo site_url('CekPembayaran'); ?>'" class="nav__link">Cek Pembayaran</a>
                            </li>
                            <li class="nav__item">
                                <a onclick="window.location.href='<?php echo site_url('Kritik'); ?>'" class="nav__link">Kritik & Saran</a>
                            </li>
                        </ul>
                    </div>

                    <span class="mobile__menu"><i class="ri-menu-line"></i></span>
                </div>
            </div>
        </nav>
    </header>

    <!-- =========== header end ============ -->

    <div class="container mt-5">
        <div class="row">
            <div class="col-md-6 form-reservasi">
                <h2>Formulir Reservasi Meja & Booking Menu</h2>
                <p>Isi data dengan lengkap dan benar</p>
                <form id="reservasiForm" action="<?= site_url('reservasi/submit') ?>" method="post">
                    <div class="mb-3">
                        <label for="nama" class="form-label">Nama Panggilan/Lengkap <span class="text-danger">*</span></label>
                        <input type="text" class="form-control" id="nama" name="nama" placeholder="Nama" required>
                    </div>
                    <div class="mb-3">
                        <label for="no_hp" class="form-label">Nomor HP <span class="text-danger">*</span></label>
                        <input type="text" class="form-control" id="no_hp" name="no_hp" placeholder="Nomor HP" required>
                    </div>
                    <div class="mb-3">
                        <label for="tanggal_reservasi" class="form-label">Tanggal Pemesanan <span class="text-danger">*</span></label>
                        <input type="date" class="form-control" id="tanggal_reservasi" name="tanggal_reservasi" required>
                    </div>
                    <div class="mb-3">
                        <label for="meja" class="form-label">Pilih Meja Yang Ingin Direservasi <span class="text-danger">*</span></label>
                        <select class="form-select" id="meja" name="meja" required>
                            <option value="" disabled selected>Pilih Meja</option>
                            <?php foreach ($meja as $m) : ?>
                                <option value="<?php echo $m->id_meja; ?>"> Nomor <?php echo $m->nomor_meja; ?> (Kapasitas <?php echo $m->kapasitas; ?> Orang)</option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <h4>Buku Menu</h4>
                    <p>Pilih menu dan isi jumlah pemesanan</p>
                    <div class="mb-3">
                        <label for="menu" class="form-label">Pilih Menu Yang Ingin Dipesan <span class="text-danger">*</span></label>
                        <select class="form-select" id="menu">
                            <option value="" disabled selected>Pilih Menu</option>
                            <?php foreach ($menu as $m) : ?>
                                <option value="<?php echo $m->id_menu; ?>" data-harga="<?php echo $m->harga; ?>"><?php echo $m->nama_menu; ?> (Rp. <?php echo number_format($m->harga, 0, ',', '.'); ?>)</option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label for="jumlah_pesanan" class="form-label">Jumlah Pesanan <span class="text-danger">*</span></label>
                        <input type="number" class="form-control" id="jumlah_pesanan" placeholder="Jumlah Pesanan">
                    </div>
                    <button type="button" class="btn btn-secondary" id="tambahMenu">Tambah Menu</button>
                    <input type="hidden" name="total_pembayaran" id="total_pembayaran" value="0">
                    <input type="hidden" name="menus" id="menus" value="">
                    <button type="submit" class="btn btn-dark mt-3">Booking Sekarang</button>
                </form>
            </div>
            <div class="col-md-6 order-summary">
                <h4>Ringkasan Pesanan</h4>
                <h5>Meja Yang Dipilih : <span class="highlight-green" id="mejaDipilih"></span></h5>
                <table class="table table-bordered table-dark">
                    <thead>
                        <tr>
                            <th>Nama Menu</th>
                            <th>Harga Satuan</th>
                            <th>Jumlah</th>
                            <th>Total</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>
                    <tbody id="orderItems">
                        <!-- Pesanan akan dimuat di sini -->
                    </tbody>
                </table>
                <div class="order-total">
                    <h5>Total Harga : <span  class="highlight-green" id="totalHarga">Rp. 0</span></h5>
                    <h5>DP Yang Harus Dibayar : <span  class="highlight-green" id="dpHarga">Rp. 0</span></h5>
                </div>
            </div>
        </div>
    </div>

    <script>
        document.getElementById('meja').addEventListener('change', function() {
            const mejaDipilih = document.getElementById('mejaDipilih');
            const mejaSelect = document.getElementById('meja');
            const meja = mejaSelect.options[mejaSelect.selectedIndex].text;
            mejaDipilih.textContent = meja;
        });

        let totalHarga = 0;
        let menus = [];

        document.getElementById('tambahMenu').addEventListener('click', function() {
            const menuSelect = document.getElementById('menu');
            const menu = menuSelect.options[menuSelect.selectedIndex];
            const jumlah = parseInt(document.getElementById('jumlah_pesanan').value);

            if (menu.value && jumlah) {
                const orderItems = document.getElementById('orderItems');
                const harga = parseInt(menu.getAttribute('data-harga'));
                const totalHargaItem = harga * jumlah;

                addItemToTable(menu.textContent, harga, jumlah, totalHargaItem, menu.value);

                totalHarga += totalHargaItem;
                menus.push({
                    id_menu: menu.value,
                    jumlah: jumlah,
                    harga: harga
                });

                document.getElementById('total_pembayaran').value = totalHarga;
                document.getElementById('menus').value = JSON.stringify(menus);
                updateTotalHarga();
            }
        });

        document.getElementById('orderItems').addEventListener('click', function(event) {
            if (event.target.classList.contains('hapusItem')) {
                const harga = parseInt(event.target.getAttribute('data-harga'));
                const id_menu = event.target.getAttribute('data-id');
                const jumlah = event.target.getAttribute('data-jumlah');

                totalHarga -= harga * jumlah;
                if (totalHarga < 0) totalHarga = 0;

                menus = menus.filter(menu => menu.id_menu != id_menu || menu.jumlah != jumlah);
                document.getElementById('total_pembayaran').value = totalHarga;
                document.getElementById('menus').value = JSON.stringify(menus);
                updateTotalHarga();
                event.target.parentElement.parentElement.remove(); // Menghapus baris tabel
            }
        });

        function addItemToTable(nama, harga, jumlah, total, id_menu) {
            const orderItems = document.getElementById('orderItems');
            const tr = document.createElement('tr');

            tr.innerHTML = `
            <td>${nama}</td>
            <td>Rp. ${harga.toLocaleString()}</td>
            <td>${jumlah}</td>
            <td>Rp. ${(harga * jumlah).toLocaleString()}</td>
            <td><button class="btn btn-danger hapusItem" data-harga="${harga}" data-id="${id_menu}" data-jumlah="${jumlah}">Hapus</button></td>
        `;

            orderItems.appendChild(tr);
        }

        function updateTotalHarga() {
            const totalHargaElem = document.getElementById('totalHarga');
            const dpHargaElem = document.getElementById('dpHarga');

            let dpHarga = totalHarga / 2;

            totalHargaElem.textContent = `Rp. ${totalHarga.toLocaleString()}`;
            dpHargaElem.textContent = `Rp. ${dpHarga.toLocaleString()}`;
        }
    </script>
    <!-- =========== footer start ============ -->
    <footer class="section footer">
        <div class="container">
            <div class="footer__wrapper">
                <div class="footer__logo">
                    <div class="logo">
                        <h1>Waroeng<span class="highlight">Nusantara</span></h1>
                    </div>
                    <button class="btn btn-secondary" onclick="window.location.href='<?php echo site_url('Login'); ?>'">Admin</button>
                </div>

                <div class="footer__box">
                    <h3 class="footer__link-title">Location</h3>
                    <ul class="footer__menu">
                        <li class="footer__menu-item">
                            <a href="#about" class="footer__link">Yogyakarta</a>
                        </li>
                    </ul>
                </div>

                <div class="footer__box">
                    <h3 class="footer__link-title">Services</h3>
                    <ul class="footer__menu">
                        <li class="footer__menu-item">
                            <a href="#about" class="footer__link">Online reservasi</a>
                        </li>
                        <li class="footer__menu-item">
                            <a href="#" class="footer__link">Fast Respon</a>
                        </li>
                        <li class="footer__menu-item">
                            <a href="#" class="footer__link">Pre-Reservation</a>
                        </li>
                        <li class="footer__menu-item">
                            <a href="#" class="footer__link">Halal</a>
                        </li>
                    </ul>
                </div>

                <div class="footer__box">
                    <h3 class="footer__link-title">Jam Oprasional</h3>
                    <ul class="footer__menu">
                        <li class="footer__menu-item">
                            <a href="#menu" class="footer__link">Senin-Jum'at: 08:00-22:00</a>
                        </li>
                        <li class="footer__menu-item">
                            <a href="#blog" class="footer__link">Sabtu: 10:00-00:00</a>
                        </li>
                        <li class="footer__menu-item">
                            <a href="#about" class="footer__link">Minggu: 10:00-20:00</a>
                        </li>
                    </ul>
                </div>

                <div class="footer__box">
                    <h3 class="footer__link-title">Social</h3>
                    <ul class="footer__menu">
                        <li class="footer__menu-item">
                            <a href="#" class="footer__link">Facebook</a>
                        </li>
                        <li class="footer__menu-item">
                            <a href="#" class="footer__link">Instagram</a>
                        </li>
                        <li class="footer__menu-item">
                            <a href="#" class="footer__link">Linkedin</a>
                        </li>
                        <li class="footer__menu-item">
                            <a href="#" class="footer__link">Twitter</a>
                        </li>
                    </ul>
                </div>
            </div>

            <p class="footer__copyright">
                © 2024 Kelompok_3 All Rights Reserved.
            </p>
        </div>
    </footer>
    <!-- =========== footer end ============ -->

    <!-- main js file -->
    <script src="<?php echo base_url('asset/app.js'); ?>"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
</body>

</html>