<?php
class Katalog extends CI_Controller {

    public function __construct() {
        parent::__construct();
        $this->load->model('Menu_model');
    }

    public function index() {
        $data['title'] = 'Katalog Menu';
        $data['menu'] = $this->Menu_model->get_menu();

        // Pisahkan menu berdasarkan kategori
        $data['makanan'] = array_filter($data['menu'], function($item) {
            return $item['kategori'] === 'Makanan';
        });

        $data['minuman'] = array_filter($data['menu'], function($item) {
            return $item['kategori'] === 'Minuman';
        });


        $this->load->view('katalog', $data);

    }
}
?>
