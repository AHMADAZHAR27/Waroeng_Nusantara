<?php
defined('BASEPATH') or exit('No direct script access allowed');

class CekPembayaran extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->load->model('CekPembayaran_model');
    }

    public function index()
    {
        $search = $this->input->post('search');
        $data['reservasi'] = $this->CekPembayaran_model->getReservasi($search);
        $data['search'] = $search;
        $this->load->view('cek_pembayaran', $data);
    }
}
