<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Menu extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->load->model('MenuModel');
        $this->load->library('form_validation');
        $this->load->helper('url');
        $this->load->library('session');

        if (!$this->session->userdata('user_id') && !in_array($this->router->fetch_method(), ['login', 'login_process'])) {
            redirect('login');
        }
    }

    public function index()
    {
        $data["menus"] = $this->MenuModel->getMenus();
        $this->load->view("admin/menu", $data);
    }

    public function tambah()
    {
        $this->form_validation->set_rules('nama_menu', 'Nama Menu', 'required');
        $this->form_validation->set_rules('detail_menu', 'Detail Menu', 'required');
        $this->form_validation->set_rules('kategori', 'Kategori', 'required');
        $this->form_validation->set_rules('stok', 'Stok', 'required');
        $this->form_validation->set_rules('harga', 'Harga', 'required|numeric');

        if ($this->form_validation->run() == FALSE) {
            $this->session->set_flashdata('error', validation_errors());
            redirect('Menu');
        }

        $config['upload_path'] = FCPATH . 'uploads/';
        $config['allowed_types'] = 'gif|jpg|jpeg|png';
        $config['max_size'] = 2048;
        $config['file_name'] = time() . '_' . $_FILES['userfile']['name'];

        $this->load->library('upload', $config);

        if (!$this->upload->do_upload('userfile')) {
            $error = array('error' => $this->upload->display_errors());
            $this->session->set_flashdata('error', $error['error']);
            redirect('Menu');
        }

        $file_data = $this->upload->data();
        $gambar_path = 'uploads/' . $file_data['file_name'];

        $data = [
            'nama_menu' => $this->input->post('nama_menu'),
            'detail_menu' => $this->input->post('detail_menu'),
            'kategori' => $this->input->post('kategori'),
            'stok' => $this->input->post('stok'),
            'harga' => $this->input->post('harga'),
            'gambar_menu' => $gambar_path
        ];

        if ($this->MenuModel->insertMenu($data)) {
            $this->session->set_flashdata('success', 'Menu berhasil ditambahkan.');
        } else {
            $this->session->set_flashdata('error', 'Gagal menambahkan menu.');
        }

        redirect('Menu');
    }

    public function edit()
    {
        $id_menu = $this->input->post('id_menu');
        $config['upload_path'] = './uploads/';
        $config['allowed_types'] = 'gif|jpg|jpeg|png';
        $config['max_size'] = 5120;
        $config['file_name'] = time() . '_' . $_FILES['userfile']['name'];

        $this->load->library('upload', $config);

        $gambar_path = $this->input->post('old_gambar');

        if ($_FILES['userfile']['name']) {
            if ($this->upload->do_upload('userfile')) {
                $file_data = $this->upload->data();
                $gambar_path = 'uploads/' . $file_data['file_name'];
            } else {
                $error = array('error' => $this->upload->display_errors());
                $this->session->set_flashdata('error', $error['error']);
                redirect('Menu');
            }
        }

        $data = [
            'nama_menu' => $this->input->post('nama_menu'),
            'detail_menu' => $this->input->post('detail_menu'),
            'kategori' => $this->input->post('kategori'),
            'stok' => $this->input->post('stok'),
            'harga' => $this->input->post('harga'),
            'gambar_menu' => $gambar_path
        ];

        if ($this->MenuModel->updateMenu($id_menu, $data)) {
            $this->session->set_flashdata('success', 'Menu berhasil diperbarui.');
        } else {
            $this->session->set_flashdata('error', 'Gagal memperbarui menu.');
        }

        redirect('Menu');
    }

    public function hapus($id)
    {
        if ($this->MenuModel->deleteMenu($id)) {
            $this->session->set_flashdata('success', 'Menu berhasil dihapus.');
        } else {
            $this->session->set_flashdata('error', 'Gagal menghapus menu.');
        }

        redirect('Menu');
    }

    public function search()
    {
        $query = $this->input->get('q');
        $data['menus'] = $this->MenuModel->searchMenus($query);
        $this->load->view('menu', $data);
    }
}
