<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Meja extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->load->model('MejaModel');
        $this->load->library('form_validation');
        $this->load->helper('url');
        $this->load->library('session');

        if (!$this->session->userdata('user_id') && !in_array($this->router->fetch_method(), ['login', 'login_process'])) {
            redirect('login');
        }
    }

    public function index()
    {
        $search = $this->input->get('search');
        $data["meja"] = $this->MejaModel->getAllMeja($search);
        $data["search"] = $search;
        $this->load->view("admin/meja", $data);
    }

    public function tambah()
    {
        $this->form_validation->set_rules('nomor_meja', 'Nomor Meja', 'required');
        $this->form_validation->set_rules('kapasitas', 'Kapasitas', 'required|numeric');

        if ($this->form_validation->run() == FALSE) {
            $this->session->set_flashdata('error', validation_errors());
            redirect('Meja');
        }

        $data = [
            'nomor_meja' => $this->input->post('nomor_meja'),
            'kapasitas' => $this->input->post('kapasitas')
        ];

        if ($this->MejaModel->insertMeja($data)) {
            $this->session->set_flashdata('success', 'Meja berhasil ditambahkan.');
        } else {
            $this->session->set_flashdata('error', 'Gagal menambahkan meja.');
        }

        redirect('Meja');
    }

    public function edit()
    {
        $id_meja = $this->input->post('id_meja');
        $this->form_validation->set_rules('nomor_meja', 'Nomor Meja', 'required');
        $this->form_validation->set_rules('kapasitas', 'Kapasitas', 'required|numeric');

        if ($this->form_validation->run() == FALSE) {
            $this->session->set_flashdata('error', validation_errors());
            redirect('Meja');
        }

        $data = [
            'nomor_meja' => $this->input->post('nomor_meja'),
            'kapasitas' => $this->input->post('kapasitas')
        ];

        if ($this->MejaModel->updateMeja($id_meja, $data)) {
            $this->session->set_flashdata('success', 'Meja berhasil diperbarui.');
        } else {
            $this->session->set_flashdata('error', 'Gagal memperbarui meja.');
        }

        redirect('Meja');
    }

    public function hapus($id)
    {
        if ($this->MejaModel->deleteMeja($id)) {
            $this->session->set_flashdata('success', 'Meja berhasil dihapus.');
        } else {
            $this->session->set_flashdata('error', 'Gagal menghapus meja.');
        }

        redirect('Meja');
    }
}
