<?php
defined('BASEPATH') or exit('No direct script access allowed');

class KritikSaran extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->load->model('KritikSaranModel');
        $this->load->library('form_validation');
        $this->load->helper('url');
        $this->load->library('session');
    }

    public function index()
    {
        $search = $this->input->get('search');
        $data["kritik_saran"] = $this->KritikSaranModel->getAllKritikSaran($search);
        $data["search"] = $search;
        $this->load->view("admin/kritik_saran", $data);
    }

    public function hapus($id)
    {
        if ($this->KritikSaranModel->deleteKritikSaran($id)) {
            $this->session->set_flashdata('success', 'Kritik dan saran berhasil dihapus.');
        } else {
            $this->session->set_flashdata('error', 'Gagal menghapus kritik dan saran.');
        }

        redirect('KritikSaran');
    }
}