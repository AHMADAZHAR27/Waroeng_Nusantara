<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Landing extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->load->model('Menu_model');
    }

    public function index()
    {
        $data['menu'] = $this->Menu_model->get_random_menu(3);

        $this->load->view('landing', $data);
    }
}
