<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Reservasi extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->load->model('Reservasi_model');
        $this->load->model('MejaModel');
        $this->load->model('MenuModel');
    }

    public function index()
    {
        $data['meja'] = $this->MejaModel->getAllMeja();
        $data['menu'] = $this->MenuModel->getMenus();
        $this->load->view('reservasi', $data);
    }

    public function submit()
    {
        $kode_pembayaran = 'INV' . date('YmdHis');
        $data_reservasi = [
            'kode_pembayaran' => $kode_pembayaran,
            'nama' => $this->input->post('nama'),
            'no_hp' => $this->input->post('no_hp'),
            'tanggal_reservasi' => $this->input->post('tanggal_reservasi'),
            'meja' => $this->input->post('meja'),
            'total_pembayaran' => $this->input->post('total_pembayaran'),
            'status_pembayaran' => 'Belum Dibayar',
            'bukti_pembayaran' => ''
        ];

        // Simpan data reservasi
        $reservasi_id = $this->Reservasi_model->insert_reservasi($data_reservasi);

        // Simpan data detail menu
        $menus = json_decode($this->input->post('menus'), true);
        foreach ($menus as $menu) {
            $menu_data = [
                'id_reservasi' => $reservasi_id,
                'id_menu' => $menu['id_menu'],
                'jumlah' => $menu['jumlah'],
                'harga' => $menu['harga']
            ];
            $this->Reservasi_model->insert_reservasi_menu($menu_data);
        }

        // Redirect ke halaman pembayaran dengan kode pembayaran
        redirect('pembayaran/index/' . $kode_pembayaran);
    }
}
