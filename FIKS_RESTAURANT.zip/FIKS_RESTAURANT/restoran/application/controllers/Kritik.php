<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Kritik extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->load->model('Kritik_model');
    }

    public function index()
    {
        $this->load->view('kritik');
    }

    public function submit()
    {
        $data = [
            'nama_pelanggan' => $this->input->post('nama_pelanggan'),
            'email' => $this->input->post('email'),
            'kritik_saran' => $this->input->post('kritik_saran'),
            'tanggal' => date('Y-m-d'),
            'waktu' => date('H:i:s')
        ];

        $this->Kritik_model->insert_kritik($data);
        $this->session->set_flashdata('message', 'Kritik & Saran berhasil terkirim!');
        redirect('kritik');
    }
}
