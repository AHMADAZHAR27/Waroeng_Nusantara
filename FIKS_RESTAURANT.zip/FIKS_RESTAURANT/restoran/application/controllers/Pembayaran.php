<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Pembayaran extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->load->model('MetodePembayaranModel');
        $this->load->model('Reservasi_model');
        $this->load->model('MejaModel');
    }

    public function index($kode_pembayaran)
    {
        $data['reservasi'] = $this->Reservasi_model->getReservasiByKode($kode_pembayaran);
        if (!$data['reservasi']) {
            show_error('Reservasi tidak ditemukan.');
        }

        $data['metode_pembayaran'] = $this->MetodePembayaranModel->getAllMetodePembayaran();
        $data['menu_dipesan'] = $this->Reservasi_model->getMenuByKodePembayaran($kode_pembayaran);
        $data['meja_dipesan'] = $this->Reservasi_model->getMejaByKodePembayaran($kode_pembayaran);

        $this->load->view('pembayaran', $data);
    }

    public function verifikasi()
    {
        $kode_pembayaran = $this->input->post('kode_pembayaran');
        $pembayaran_tipe = $this->input->post('pembayaran_tipe');
        $bukti_pembayaran = $_FILES['bukti_pembayaran'];

        if ($bukti_pembayaran['error'] === UPLOAD_ERR_OK) {
            $ext = pathinfo($bukti_pembayaran['name'], PATHINFO_EXTENSION);
            $filename = $kode_pembayaran . '.' . $ext;
            move_uploaded_file($bukti_pembayaran['tmp_name'], './uploads_pembayaran/' . $filename);

            $data = [
                'status_pembayaran' => $pembayaran_tipe === 'DP' ? 'DP Dibayar' : 'Lunas',
                'bukti_pembayaran' => $filename
            ];

            $this->Reservasi_model->update_reservasi($kode_pembayaran, $data);
            $this->session->set_flashdata('message', 'Pembayaran berhasil diverifikasi.');
            redirect('Pembayaran/index/' . $kode_pembayaran);
        } else {
            $this->session->set_flashdata('error', 'Gagal mengupload bukti pembayaran.');
            redirect('Pembayaran/index/' . $kode_pembayaran);
        }
    }
}
