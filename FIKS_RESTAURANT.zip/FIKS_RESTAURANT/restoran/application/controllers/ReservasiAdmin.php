<?php

defined('BASEPATH') or exit('No direct script access allowed');

class ReservasiAdmin extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->load->model('ReservasiAdmin_model');
        if (!$this->session->userdata('user_id') && !in_array($this->router->fetch_method(), ['login', 'login_process'])) {
            redirect('login');
        }
    }

    public function index()
    {
        $search = $this->input->get('search');
        $data['reservasi'] = $this->ReservasiAdmin_model->getAllReservasi($search);
        $data['search'] = $search;
        $this->load->view('admin/reservasi_admin', $data);
    }

    public function get_detail_menu($id_reservasi)
    {
        $menu_dipesan = $this->ReservasiAdmin_model->getMenuByReservasiId($id_reservasi);
        if (!$menu_dipesan) {
            show_404();
        }
        echo json_encode($menu_dipesan);
    }

    public function get_reservasi($id_reservasi)
    {
        $reservasi = $this->ReservasiAdmin_model->getReservasiById($id_reservasi);
        if (!$reservasi) {
            show_404();
        }
        echo json_encode($reservasi);
    }

    public function update_reservasi($id_reservasi)
    {
        $data = [
            'status_pembayaran' => $this->input->post('status_pembayaran')
        ];
        $update_result = $this->ReservasiAdmin_model->updateReservasi($id_reservasi, $data);
        if ($update_result) {
            $this->session->set_flashdata('success', 'Status pembayaran berhasil diperbarui.');
        } else {
            $this->session->set_flashdata('error', 'Gagal memperbarui status pembayaran.');
        }
        redirect('ReservasiAdmin');
    }

    public function delete_reservasi($id_reservasi)
    {
        $delete_menu_result = $this->ReservasiAdmin_model->deleteMenuByReservasiId($id_reservasi);
        $delete_reservasi_result = $this->ReservasiAdmin_model->deleteReservasi($id_reservasi);
        if ($delete_menu_result && $delete_reservasi_result) {
            $this->session->set_flashdata('success', 'Reservasi berhasil dihapus.');
        } else {
            $this->session->set_flashdata('error', 'Gagal menghapus reservasi.');
        }
        redirect('ReservasiAdmin');
    }
}
