<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Login extends CI_Controller
{

    public function __construct()
    {
        parent::__construct();
        $this->load->model('UserModel');
        $this->load->library('form_validation');
        $this->load->helper('url');
        $this->load->library('session');
    }

    public function index()
    {
        $this->load->view('login');
    }

    public function login_process()
    {
        $username = $this->input->post('username');
        $password = $this->input->post('password');

        if (empty($username) || empty($password)) {
            $data['error'] = 'Username dan Password Salah!!';
            $this->load->view('login', $data);
            return;
        }

        $user = $this->UserModel->login_user($username, $password);

        if ($user) {
            $this->session->set_userdata('user_id', $user->iduser);
            $this->session->set_userdata('username', $user->username);
            $this->session->set_flashdata('login_success', 'BERHASIL LOGIN - HALO ADMIN');

            redirect('Menu');
        } else {
            $data['error'] = 'Invalid username or password';
            $this->load->view('login', $data);
        }
    }

    public function logout()
    {
        $this->session->sess_destroy();

        redirect('landing');
    }
}
