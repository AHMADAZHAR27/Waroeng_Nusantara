<?php
defined('BASEPATH') or exit('No direct script access allowed');

class MetodePembayaran extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->load->model('MetodePembayaranModel');
        $this->load->library('form_validation');
        $this->load->helper('url');
        $this->load->library('session');

        if (!$this->session->userdata('user_id') && !in_array($this->router->fetch_method(), ['login', 'login_process'])) {
            redirect('login');
        }
    }

    public function index()
    {
        $search = $this->input->get('search');
        $data["metode_pembayaran"] = $this->MetodePembayaranModel->getAllMetodePembayaran($search);
        $data["search"] = $search;
        $this->load->view("admin/metode_pembayaran", $data);
    }

    public function tambah()
    {
        $this->form_validation->set_rules('bank', 'Bank', 'required');
        $this->form_validation->set_rules('rekening', 'Rekening', 'required');
        $this->form_validation->set_rules('nama_rekening', 'Nama Rekening', 'required');

        if ($this->form_validation->run() == FALSE) {
            $this->session->set_flashdata('error', validation_errors());
            redirect('MetodePembayaran');
        }

        $data = [
            'bank' => $this->input->post('bank'),
            'rekening' => $this->input->post('rekening'),
            'nama_rekening' => $this->input->post('nama_rekening')
        ];

        if ($this->MetodePembayaranModel->insertMetodePembayaran($data)) {
            $this->session->set_flashdata('success', 'Metode pembayaran berhasil ditambahkan.');
        } else {
            $this->session->set_flashdata('error', 'Gagal menambahkan metode pembayaran.');
        }

        redirect('MetodePembayaran');
    }

    public function edit()
    {
        $id_mp = $this->input->post('id_mp');
        $this->form_validation->set_rules('bank', 'Bank', 'required');
        $this->form_validation->set_rules('rekening', 'Rekening', 'required');
        $this->form_validation->set_rules('nama_rekening', 'Nama Rekening', 'required');

        if ($this->form_validation->run() == FALSE) {
            $this->session->set_flashdata('error', validation_errors());
            redirect('MetodePembayaran');
        }

        $data = [
            'bank' => $this->input->post('bank'),
            'rekening' => $this->input->post('rekening'),
            'nama_rekening' => $this->input->post('nama_rekening')
        ];

        if ($this->MetodePembayaranModel->updateMetodePembayaran($id_mp, $data)) {
            $this->session->set_flashdata('success', 'Metode pembayaran berhasil diperbarui.');
        } else {
            $this->session->set_flashdata('error', 'Gagal memperbarui metode pembayaran.');
        }

        redirect('MetodePembayaran');
    }

    public function hapus($id)
    {
        if ($this->MetodePembayaranModel->deleteMetodePembayaran($id)) {
            $this->session->set_flashdata('success', 'Metode pembayaran berhasil dihapus.');
        } else {
            $this->session->set_flashdata('error', 'Gagal menghapus metode pembayaran.');
        }

        redirect('MetodePembayaran');
    }


}
