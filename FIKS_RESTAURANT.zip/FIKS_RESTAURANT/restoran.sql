-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 23, 2024 at 04:02 PM
-- Server version: 10.4.21-MariaDB
-- PHP Version: 8.0.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `restoran`
--

-- --------------------------------------------------------

--
-- Table structure for table `kritik_saran`
--

CREATE TABLE `kritik_saran` (
  `id` int(11) NOT NULL,
  `nama_pelanggan` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `kritik_saran` text NOT NULL,
  `tanggal` date NOT NULL DEFAULT curdate(),
  `waktu` time NOT NULL DEFAULT curtime()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `kritik_saran`
--

INSERT INTO `kritik_saran` (`id`, `nama_pelanggan`, `email`, `kritik_saran`, `tanggal`, `waktu`) VALUES
(1, 'asep', 'asepacumalaka@gmail.com', 'nasi nya basi cuy', '2024-06-05', '03:19:26'),
(2, 'ujang', 'ujangmanehkasep@yahoo.com', 'request nasi uduk yang dateng bapak nya', '2024-06-18', '00:21:20'),
(3, 'Asep Sumedang', 'AsepRendang@gmail.com', 'Mahal Uy', '2024-06-22', '18:52:43');

-- --------------------------------------------------------

--
-- Table structure for table `meja`
--

CREATE TABLE `meja` (
  `id_meja` int(11) NOT NULL,
  `nomor_meja` int(11) NOT NULL,
  `kapasitas` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `meja`
--

INSERT INTO `meja` (`id_meja`, `nomor_meja`, `kapasitas`) VALUES
(1, 1, 7),
(2, 2, 10),
(3, 3, 2),
(4, 4, 5),
(5, 5, 3),
(6, 6, 7),
(7, 7, 1),
(8, 8, 7),
(9, 9, 6),
(10, 10, 4),
(11, 11, 1),
(12, 12, 3),
(13, 13, 9),
(14, 14, 2),
(15, 15, 5),
(16, 16, 8),
(17, 17, 2),
(18, 18, 3),
(19, 19, 4),
(20, 20, 10);

-- --------------------------------------------------------

--
-- Table structure for table `menu`
--

CREATE TABLE `menu` (
  `id_menu` int(11) NOT NULL,
  `nama_menu` varchar(255) NOT NULL,
  `detail_menu` text DEFAULT NULL,
  `kategori` varchar(20) DEFAULT NULL,
  `stok` varchar(20) DEFAULT NULL,
  `harga` int(11) DEFAULT NULL,
  `gambar_menu` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `menu`
--

INSERT INTO `menu` (`id_menu`, `nama_menu`, `detail_menu`, `kategori`, `stok`, `harga`, `gambar_menu`) VALUES
(2, 'Sate Ayam', 'Sate ayam dengan bumbu kacang', 'Makanan', 'Tersedia', 30000, 'uploads/1718634829_sateayam.jpg'),
(3, 'Gado-Gado', 'Salad khas Indonesia dengan saus kacang', 'Makanan', 'Habis', 20000, 'uploads/1718634732_gado.jpeg'),
(4, 'Es Campur', 'Minuman es dengan campuran buah-buahan dan sirup', 'Minuman', 'Tersedia', 15000, 'uploads/1718634714_escampur.jpeg'),
(5, 'Bakso', 'Bakso sapi dengan kuah kaldu', 'Makanan', 'Tersedia', 20000, 'uploads/1718634696_bakso.jpeg'),
(6, 'Rendang', 'Daging sapi dimasak dengan bumbu rendang khas Padang', 'Makanan', 'Tersedia', 35000, 'uploads/1718625268_rendang.jpg'),
(11, 'Nasi Uduk', 'Free Es teh', 'Makanan', 'Habis', 30000, 'uploads/1718625205_nasiuduk.jpeg');

-- --------------------------------------------------------

--
-- Table structure for table `metode_pembayaran`
--

CREATE TABLE `metode_pembayaran` (
  `id_mp` int(11) NOT NULL,
  `bank` varchar(100) NOT NULL,
  `rekening` varchar(50) NOT NULL,
  `nama_rekening` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `metode_pembayaran`
--

INSERT INTO `metode_pembayaran` (`id_mp`, `bank`, `rekening`, `nama_rekening`) VALUES
(2, 'DANA', '0888118811881', 'ASEP KING'),
(3, 'BANK BRI', '0091919191919', 'ASEP GACOR');

-- --------------------------------------------------------

--
-- Table structure for table `reservasi`
--

CREATE TABLE `reservasi` (
  `id_reservasi` int(11) NOT NULL,
  `kode_pembayaran` varchar(50) NOT NULL,
  `nama` varchar(100) NOT NULL,
  `no_hp` int(15) NOT NULL,
  `tanggal_reservasi` date NOT NULL,
  `meja` int(50) NOT NULL,
  `total_pembayaran` int(50) NOT NULL,
  `status_pembayaran` varchar(50) NOT NULL,
  `bukti_pembayaran` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `reservasi`
--

INSERT INTO `reservasi` (`id_reservasi`, `kode_pembayaran`, `nama`, `no_hp`, `tanggal_reservasi`, `meja`, `total_pembayaran`, `status_pembayaran`, `bukti_pembayaran`) VALUES
(31, 'INV20240623125031', 'RAJOOO', 2147483647, '2024-06-29', 10, 260000, 'Belum Dibayar', ''),
(32, 'INV20240623125109', 'Opet', 2147483647, '2024-06-25', 15, 45000, 'Belum Dibayar', ''),
(33, 'INV20240623125506', 'JAMALUDIN', 2147483647, '2024-06-28', 18, 315000, 'Belum Dibayar', ''),
(34, 'INV20240623125551', 'Kuatani', 214124, '2024-07-04', 8, 3500000, 'Belum Dibayar', ''),
(35, 'INV20240623125915', 'Azzahra Nabila Wibirasya ', 2147483647, '2024-06-26', 13, 500000, 'Belum Dibayar', ''),
(36, 'INV20240623131713', 'Kurniqi', 2147483647, '2024-06-28', 10, 140000, 'Lunas', 'INV20240623131713.png');

-- --------------------------------------------------------

--
-- Table structure for table `reservasi_menu`
--

CREATE TABLE `reservasi_menu` (
  `id` int(11) NOT NULL,
  `id_reservasi` int(11) DEFAULT NULL,
  `id_menu` int(11) DEFAULT NULL,
  `jumlah` int(11) DEFAULT NULL,
  `harga` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `reservasi_menu`
--

INSERT INTO `reservasi_menu` (`id`, `id_reservasi`, `id_menu`, `jumlah`, `harga`) VALUES
(1, 31, 2, 4, 30000),
(2, 31, 3, 4, 20000),
(3, 31, 4, 4, 15000),
(4, 32, 4, 3, 15000),
(5, 33, 4, 3, 15000),
(6, 33, 5, 3, 20000),
(7, 33, 6, 3, 35000),
(8, 33, 6, 3, 35000),
(9, 34, 4, 100, 15000),
(10, 34, 5, 100, 20000),
(11, 35, 6, 5, 35000),
(12, 35, 2, 5, 30000),
(13, 35, 6, 5, 35000),
(14, 36, 6, 4, 35000);

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `iduser` int(11) NOT NULL,
  `username` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`iduser`, `username`, `password`) VALUES
(1, 'admin', 'admin123');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `kritik_saran`
--
ALTER TABLE `kritik_saran`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `meja`
--
ALTER TABLE `meja`
  ADD PRIMARY KEY (`id_meja`);

--
-- Indexes for table `menu`
--
ALTER TABLE `menu`
  ADD PRIMARY KEY (`id_menu`);

--
-- Indexes for table `metode_pembayaran`
--
ALTER TABLE `metode_pembayaran`
  ADD PRIMARY KEY (`id_mp`);

--
-- Indexes for table `reservasi`
--
ALTER TABLE `reservasi`
  ADD PRIMARY KEY (`id_reservasi`),
  ADD KEY `fk_meja` (`meja`);

--
-- Indexes for table `reservasi_menu`
--
ALTER TABLE `reservasi_menu`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_reservasi` (`id_reservasi`),
  ADD KEY `fk_menu` (`id_menu`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`iduser`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `kritik_saran`
--
ALTER TABLE `kritik_saran`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `meja`
--
ALTER TABLE `meja`
  MODIFY `id_meja` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `menu`
--
ALTER TABLE `menu`
  MODIFY `id_menu` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `metode_pembayaran`
--
ALTER TABLE `metode_pembayaran`
  MODIFY `id_mp` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `reservasi`
--
ALTER TABLE `reservasi`
  MODIFY `id_reservasi` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=37;

--
-- AUTO_INCREMENT for table `reservasi_menu`
--
ALTER TABLE `reservasi_menu`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `iduser` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `reservasi`
--
ALTER TABLE `reservasi`
  ADD CONSTRAINT `fk_meja` FOREIGN KEY (`meja`) REFERENCES `meja` (`id_meja`),
  ADD CONSTRAINT `reservasi_ibfk_1` FOREIGN KEY (`meja`) REFERENCES `meja` (`id_meja`);

--
-- Constraints for table `reservasi_menu`
--
ALTER TABLE `reservasi_menu`
  ADD CONSTRAINT `fk_menu` FOREIGN KEY (`id_menu`) REFERENCES `menu` (`id_menu`),
  ADD CONSTRAINT `fk_reservasi` FOREIGN KEY (`id_reservasi`) REFERENCES `reservasi` (`id_reservasi`),
  ADD CONSTRAINT `reservasi_menu_ibfk_1` FOREIGN KEY (`id_reservasi`) REFERENCES `reservasi` (`id_reservasi`),
  ADD CONSTRAINT `reservasi_menu_ibfk_2` FOREIGN KEY (`id_menu`) REFERENCES `menu` (`id_menu`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
